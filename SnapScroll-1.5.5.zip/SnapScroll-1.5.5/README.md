# SnapScroll 1.5.5

SnapScroll is an Android accessibility-based sound controller. It can trigger configured scroll, back, open-app, lock-screen, or wake-screen actions from a sound event. Raw microphone audio is processed locally and is not uploaded or saved as recordings.

## Changes in 1.5.5

- Fixed a Java compile error. `transient` is a reserved word in Java, and the transient-ratio value added in 1.5.2 used it as a variable name in `SoundMonitorService.java`. It is now `transientRatio`. The compiler error from this also hid the real error location, which is why the log pointed at unrelated lines.
- No behaviour changes.

## Changes in 1.5.4

- Fixed a Gradle build failure in `app/build.gradle.kts`. In Gradle Kotlin scripts a bare `java.` prefix refers to Gradle's `java` extension, so `java.io.File(...)` did not compile. The script now imports `File` and `HttpURLConnection`.
- No changes to the app code in this version.

## Changes in 1.5.3

Battery and CPU
- The microphone is read in 20 ms blocks instead of 10 ms, which halves the number of CPU wakeups while listening.
- When every sound is turned off, the classifier is skipped.
- The YAMNet model runs only when a clap or whistle is possible. Your-sound matching never waits on the model.
- The pulse animation on the main screen stops when the screen is not visible.

Memory
- Audio clips are stored as 16-bit samples instead of 32-bit floats, halving the memory held per candidate.
- The model's input buffer is reused rather than allocated for every clip.
- Work is capped at three clips in flight. If the model falls behind, extra candidates are dropped rather than queued in RAM.

Precision
- Your sound is matched against each of your three recordings and accepted if it is close to any of them. The old averaged template blurred the takes together.
- The threshold is calibrated leave-one-out: each take is compared with the other two, so a tight recording gets a stricter threshold and a loose one a more forgiving one.
- Profiles from 1.5.2 keep working. Re-recording gives the per-take matching.

Not changed, and not measurable here
- The classifier runs on the CPU. The audio model does not use the GPU, and I have not added a GPU delegate because I cannot test one.
- Battery, RAM and accuracy figures need measuring on the phone with Android Studio's profiler and logcat (tag SnapScrollTune).

## Changes in 1.5.2

- **Clap must be a transient.** Each candidate now measures how much of its energy sits in the ~20 ms around its loudest frame. A clap is short and sharp, so it scores high. Speech, humming and sustained whistles score low. A clap needs a ratio of at least 0.20 (provisional) before YAMNet's clap score counts.
- **Whistles reach the classifier.** The onset gate no longer requires peak/rms above 1.30. A pure whistle sits near 1.41 and was often lost under noise. Clicks are still rejected by YAMNet.
- **Less work per sound.** YAMNet runs only when a clap or whistle is possible. Custom-sound matching uses the audio features alone, so it no longer waits on the model.
- **Calibration from logcat.** Every candidate writes one line under the tag `SnapScrollTune`, with peak, transient ratio, every class score, the custom score, the threshold and the decision. Filter with `adb logcat -s SnapScrollTune`.
- Version 1.5.2 (code 8).

## Changes in 1.5.1

- **Labels by name, not index.** Clap, finger-snap, tap, knock, slam, whistle and train-whistle scores are read from the model's own label names. Previously they were read from hard-coded AudioSet indices, which would silently pick the wrong class if the bundled model's label order differed. If the model has no `Clapping` label, the log says so.
- **Enrolled sound compares like with like.** Enrollment records the loudest 100 ms of a sound. Detection previously used the tail of the event instead, so the two did not describe the same part of the sound. Detection now uses the 100 ms window centred on the loudest sample, matching enrollment.
- **Adaptive threshold for your sound.** The saved threshold is set from how consistent your three recordings are, clamped to 0.85–0.98. The old fixed 0.92 was loose for cosine similarity on positive spectral features, so unrelated sounds could match. Profiles recorded on 1.5 are cleared once more, so record again.
- **Fewer double-triggers.** After an event, the detector stays disarmed until 100 ms of quiet. One clap's reverberation, or one long whistle cut at its 500 ms limit, used to be able to count as a second sound and fire the double action.
- **Clean stop and restart.** Stopping waits for the audio thread before releasing the microphone. Late results or read errors from an old session are ignored, so a stop-then-start can no longer be shut down by a stale error.
- **Conflicting matches are resolved.** When more than one detector matched, the old code dropped the event. It now uses a fixed priority: your sound, then clap, then whistle.
- **Recording race fixed.** A take still being recorded when the sheet is closed can no longer be added to a later session.
- **Build.** The asset-merge tasks depend on the model download, so the APK cannot package before the model exists. The download has connect and read timeouts. Version is now 1.5.1 (code 7).

## Sound recognition in 1.5


- **Clap and Whistle:** now use Google's MediaPipe Tasks Audio with the YAMNet on-device audio classifier. YAMNet predicts 521 AudioSet sound classes, including separate `Clapping`, `Finger snapping`, and `Whistling` classes. SnapScroll checks the clap prediction against finger-snapping, tap, knock, and slam scores before accepting a clap.
- **Event capture:** the old 20 ms peak-only classification and contradictory minimum-duration rule have been removed. A lightweight waveform gate captures a candidate event with surrounding audio; the classifier decides what it is. The classifier input is a 0.975-second mono 16 kHz clip.
- **Your sound:** still uses a locally stored acoustic fingerprint rather than a trained personalized neural model. Enrollment now samples a 100 ms segment instead of a 20 ms sliver. The previous profile is cleared once on first launch of 1.5, so record the three samples again.
- **Single/double timing:** the gap is calculated from candidate event timestamps. Single and double actions remain independent for each trigger type.

## Important limitations

YAMNet is a general sound-event model trained on AudioSet, not a model trained specifically on this phone, room, or user's clap. It can still confuse acoustically similar sounds, and low-volume/distant claps may be missed. The thresholds in this version are starting values and need tests on the target phone with actual claps, mouth clicks, finger snaps, wall taps, and background audio. No honest claim of perfect precision can be made without those tests.

`Your sound` is still a small spectral fingerprint matcher, not a learned embedding model. It works best with a distinct, repeatable sound that differs from everyday room sounds. A future truly personalized model should be trained on positive examples of the chosen sound plus negative examples such as tongue clicks, teeth clicks, taps, and speech.

The YAMNet model is downloaded at build time from the MediaPipe community model repository and verified against a pinned SHA-256 checksum. It is packaged in the APK and runs offline after installation. The first build therefore needs network access.

## Build

Open this folder in Android Studio and build the `app` debug APK, or push it to GitHub and run the included `Build SnapScroll APK` workflow. The Gradle pre-build task downloads and checksum-verifies `yamnet.tflite` before packaging. The project uses MediaPipe Tasks Audio `1.2.3`.

## Permissions and Android behavior

- Microphone permission and a foreground microphone service are required for listening.
- Accessibility permission is required for cross-app scrolling and Android global actions.
- Lock screen uses Android's supported Accessibility global action on compatible Android versions.
- Wake screen does not unlock a secured device or bypass its PIN, pattern, password, or biometrics.

## Build/test status

The source ZIP and Gradle configuration have been checked. This environment does not have Android SDK/Gradle installed and cannot compile or run an APK on a physical phone. Device-specific threshold calibration and end-to-end tests are still required.
