package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier;
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier.AudioClassifierOptions;
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifierResult;
import com.google.mediapipe.tasks.audio.core.RunningMode;
import com.google.mediapipe.tasks.components.containers.AudioData;
import com.google.mediapipe.tasks.components.containers.AudioData.AudioDataFormat;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.Classifications;
import com.google.mediapipe.tasks.components.containers.ClassificationResult;
import com.google.mediapipe.tasks.core.BaseOptions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/** On-device sound listener. Raw microphone audio is only held in short-lived memory buffers. */
public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static volatile boolean isRunning = false;
    public static volatile String lastError = null;

    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private static final int RATE = 16000;
    private static final int FRAME_SAMPLES = 320;              // 20 ms (half the wakeups of 10 ms)
    private static final int CLIP_SAMPLES = 15600;             // YAMNet: 0.975 s at 16 kHz
    private static final int PREROLL_SAMPLES = 11200;          // 700 ms before event end
    private static final int LOCAL_SAMPLES = 1600;             // 100 ms window for the enrolled-sound matcher
    private static final int REARM_SAMPLES = 1600;             // 100 ms of quiet before a new onset may start
    private static final long MIN_EVENT_GAP_NS = 120_000_000L;
    private static final float DEFAULT_CUSTOM_THRESHOLD = 0.92f;
    /** Clap = a short transient: share of the event's energy in the ~20 ms around its loudest frame. */
    private static final float CLAP_MIN_TRANSIENT = 0.20f;
    private static final int ONSET_MIN_PEAK = 220;
    private static final String TUNE_TAG = "SnapScrollTune";

    // YAMNet/AudioSet label names. Looked up by name from the model's own labels, never by index.
    private static final String LABEL_CLAP = "Clapping";
    private static final String LABEL_SNAP = "Finger snapping";
    private static final String LABEL_TAP = "Tap";
    private static final String LABEL_KNOCK = "Knock";
    private static final String LABEL_SLAM = "Slam";
    private static final String LABEL_WHISTLE = "Whistling";
    private static final String LABEL_TRAIN_WHISTLE = "Train whistle";

    private AudioRecord recorder;
    private AudioClassifier classifier;
    private ExecutorService classifierExecutor;
    private Thread worker;
    private volatile boolean keepRunning;
    /** Incremented on every start and stop so late callbacks from an old session are ignored. */
    private volatile int session = 0;
    private static volatile boolean labelsChecked = false;
    private static final int MAX_IN_FLIGHT = 3;
    private final java.util.concurrent.atomic.AtomicInteger inFlight = new java.util.concurrent.atomic.AtomicInteger();
    /** Reused by the single classifier thread, so no large allocation per clip. */
    private final float[] yamnetInput = new float[CLIP_SAMPLES];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastCandidateNs = 0;
    private long pendingSingleNs = 0;
    private String pendingAction, pendingPackage, pendingDoubleAction, pendingDoublePackage;
    private Runnable pendingSingleRunnable;

    private static final class PendingClip {
        final short[] samples = new short[CLIP_SAMPLES];
        final long eventNs;
        final int peak;
        final float transientRatio;
        int writeIndex = PREROLL_SAMPLES;

        PendingClip(short[] preRoll, int nextPreRollIndex, long eventNs, int peak, float transientRatio) {
            this.eventNs = eventNs;
            this.peak = peak;
            this.transientRatio = transientRatio;
            int source = nextPreRollIndex;
            for (int i = 0; i < PREROLL_SAMPLES; i++) {
                samples[i] = preRoll[source];
                source = (source + 1) % preRoll.length;
            }
        }

        boolean append(short[] frame, int count) {
            int copy = Math.min(count, CLIP_SAMPLES - writeIndex);
            System.arraycopy(frame, 0, samples, writeIndex, copy);
            writeIndex += copy;
            return writeIndex >= CLIP_SAMPLES;
        }
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopMonitoring();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!isRunning) startMonitoring();
        return isRunning ? START_STICKY : START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SnapScroll is active")
                .setContentText("On-device sound recognition: clap, whistle and your sound")
                .setContentIntent(pi).setOngoing(true).build();
    }

    private void startMonitoring() {
        session++;
        inFlight.set(0);
        try {
            lastError = null;
            startForeground(NOTIFICATION_ID, notification());

            BaseOptions baseOptions = BaseOptions.builder().setModelAssetPath("yamnet.tflite").build();
            AudioClassifierOptions options = AudioClassifierOptions.builder()
                    .setBaseOptions(baseOptions)
                    .setRunningMode(RunningMode.AUDIO_CLIPS)
                    .setMaxResults(521)
                    .build();
            classifier = AudioClassifier.createFromOptions(this, options);
            classifierExecutor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "SnapScroll-YAMNet");
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            });

            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android reports no usable microphone buffer: " + min);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE * 2));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Microphone could not be initialised");
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Microphone did not start recording");

            keepRunning = true;
            isRunning = true;
            final int sess = session;
            worker = new Thread(() -> readLoop(sess), "SnapScroll-Audio");
            worker.start();
        } catch (Exception e) {
            keepRunning = false;
            isRunning = false;
            lastError = "Sound recognition could not start: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            releaseRecorder();
            releaseClassifier();
            stopForeground(true);
            stopSelf();
            Log.e("SnapScroll", "Unable to start sound recognition", e);
        }
    }

    /**
     * The waveform gate only finds candidate events; YAMNet decides what they are.
     * After each event the gate stays disarmed until the room has been quiet for REARM_SAMPLES.
     * This stops one clap's reverberation, or one long whistle cut at the 500 ms limit, from
     * being counted as a second sound (which would fire the double-sound action).
     */
    private void readLoop(final int sess) {
        short[] frame = new short[FRAME_SAMPLES];
        short[] preRoll = new short[PREROLL_SAMPLES];
        int preIndex = 0;
        ArrayList<PendingClip> pending = new ArrayList<>();
        boolean inEvent = false;
        boolean armed = true;
        int quietFrames = 0;
        int quietSamples = 0;
        int eventSamples = 0;
        int eventPeak = 0;
        long eventStartNs = 0;
        double eventEnergy = 0, bestFrameEnergy = 0, afterPeakEnergy = 0;
        boolean afterPending = false;
        double noiseRms = 24.0;
        AudioRecord active = recorder;

        while (keepRunning && active != null && sess == session) {
            int n = active.read(frame, 0, frame.length);
            if (n < 0) {
                // Only report a failure if this session is still meant to be running.
                if (keepRunning && sess == session) {
                    final int err = n;
                    handler.post(() -> {
                        if (sess != session) return;
                        lastError = "Microphone read failed (" + err + ")";
                        isRunning = false;
                        stopSelf();
                    });
                }
                break;
            }
            if (n <= 0) continue;

            // Finish all already-open clips with this frame.
            Iterator<PendingClip> iterator = pending.iterator();
            while (iterator.hasNext()) {
                PendingClip clip = iterator.next();
                if (clip.append(frame, n)) {
                    iterator.remove();
                    submitClassification(clip, sess);
                }
            }

            double sum = 0.0;
            int peak = 0;
            for (int i = 0; i < n; i++) {
                int v = frame[i];
                sum += (double) v * v;
                peak = Math.max(peak, Math.abs(v));
            }
            double rms = Math.sqrt(sum / n);

            // Maintain pre-roll in chronological circular-buffer form.
            for (int i = 0; i < n; i++) {
                preRoll[preIndex] = frame[i];
                preIndex = (preIndex + 1) % preRoll.length;
            }

            boolean quiet;
            if (!inEvent) {
                noiseRms = noiseRms * 0.98 + Math.min(rms, noiseRms * 1.6) * 0.02;
                quiet = rms < Math.max(32.0, noiseRms * 1.55);
                if (!armed) {
                    quietSamples = quiet ? quietSamples + n : 0;
                    if (quietSamples >= REARM_SAMPLES) armed = true;
                } else {
                    double onsetGate = Math.max(34.0, noiseRms * 2.2);
                    // Moderate gate only. The old peak/rms > 1.3 test rejected pure whistles (whose
                    // peak/rms is about 1.41 but drops under noise); clicks are rejected downstream.
                    if (rms > onsetGate && peak > ONSET_MIN_PEAK) {
                        long now = SystemClock.elapsedRealtimeNanos();
                        if (now - lastCandidateNs >= MIN_EVENT_GAP_NS) {
                            inEvent = true;
                            eventSamples = n;
                            eventPeak = peak;
                            eventStartNs = now;
                            quietFrames = 0;
                            eventEnergy = sum;
                            bestFrameEnergy = sum;
                            afterPeakEnergy = 0;
                            afterPending = true;
                        }
                    }
                }
            } else {
                eventSamples += n;
                eventEnergy += sum;
                if (afterPending) { afterPeakEnergy = sum; afterPending = false; }
                if (peak > eventPeak) {
                    eventPeak = peak;
                    bestFrameEnergy = sum;
                    afterPeakEnergy = 0;
                    afterPending = true;
                }
                quiet = rms < Math.max(32.0, noiseRms * 1.55);
                quietFrames = quiet ? quietFrames + 1 : 0;
                if (quietFrames >= 2 || eventSamples >= RATE / 2) {
                    inEvent = false;
                    quietFrames = 0;
                    quietSamples = 0;
                    armed = false;
                    lastCandidateNs = eventStartNs;
                    float transientRatio = (float) Math.min(1.0,
                            (bestFrameEnergy + afterPeakEnergy) / Math.max(1.0, eventEnergy));
                    pending.add(new PendingClip(preRoll, preIndex, eventStartNs, eventPeak, transientRatio));
                }
            }
        }
    }

    private void submitClassification(PendingClip clip, int sess) {
        ExecutorService executor = classifierExecutor;
        if (executor == null || classifier == null) return;
        if (inFlight.get() >= MAX_IN_FLIGHT) {
            // The model is behind real time. Drop this candidate rather than queue audio in RAM.
            Log.w(TUNE_TAG, "dropped a candidate: classifier busy");
            return;
        }
        inFlight.incrementAndGet();
        try {
            executor.execute(() -> {
                try {
                    SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
                    if (!p.getBoolean("sound_enabled", true)) return;
                    boolean clapPossible = p.getBoolean("clap_on", true) && clip.peak >= ONSET_MIN_PEAK
                            && clip.transientRatio >= CLAP_MIN_TRANSIENT;
                    boolean whistlePossible = p.getBoolean("whistle_on", false);
                    final Map<String, Float> scores = (clapPossible || whistlePossible)
                            ? classifyWithYamnet(toYamnetInput(clip.samples)) : new HashMap<>();
                    double[] features = AudioFeatures.extract(loudestWindow(clip), LOCAL_SAMPLES);
                    handler.post(() -> {
                        if (sess == session) classifyAndDispatch(features, scores, clip.eventNs, clip.peak, clip.transientRatio);
                    });
                } catch (Exception e) {
                    Log.e("SnapScroll", "YAMNet classification failed", e);
                    handler.post(() -> {
                        if (sess == session) lastError = "Sound model error: " + String.valueOf(e.getMessage());
                    });
                } finally {
                    inFlight.decrementAndGet();
                }
            });
        } catch (RejectedExecutionException e) {
            inFlight.decrementAndGet();
            Log.e("SnapScroll", "Could not queue sound classification", e);
        }
    }

    private float[] toYamnetInput(short[] src) {
        for (int i = 0; i < src.length; i++) yamnetInput[i] = src[i] / 32768.0f;
        return yamnetInput;
    }

    /**
     * The 100 ms window centred on the loudest sample of the clip. Enrollment also records the
     * loudest 100 ms, so both sides describe the same part of the sound (the transient itself).
     * Previously detection used the tail of the event, which did not match the enrolled features.
     */
    private static short[] loudestWindow(PendingClip clip) {
        int peakAt = 0;
        int best = -1;
        for (int i = 0; i < clip.writeIndex; i++) {
            int a = Math.abs(clip.samples[i]);
            if (a > best) { best = a; peakAt = i; }
        }
        int start = Math.max(0, Math.min(CLIP_SAMPLES - LOCAL_SAMPLES, peakAt - LOCAL_SAMPLES / 2));
        short[] local = new short[LOCAL_SAMPLES];
        for (int i = 0; i < LOCAL_SAMPLES; i++) {
            local[i] = clip.samples[start + i];
        }
        return local;
    }

    /** Returns the highest score for each AudioSet label name. */
    private Map<String, Float> classifyWithYamnet(float[] samples) {
        AudioDataFormat format = AudioDataFormat.builder()
                .setNumOfChannels(1)
                .setSampleRate((float) RATE)
                .build();
        AudioData audioData = AudioData.create(format, samples.length);
        audioData.load(samples);
        AudioClassifierResult result = classifier.classify(audioData);
        Map<String, Float> scores = new HashMap<>();
        if (result == null) return scores;
        for (ClassificationResult window : result.classificationResults()) {
            for (Classifications head : window.classifications()) {
                for (Category category : head.categories()) {
                    String name = category.categoryName();
                    if (name == null) continue;
                    Float previous = scores.get(name);
                    float score = category.score();
                    scores.put(name, previous == null ? score : Math.max(previous, score));
                }
            }
        }
        if (!labelsChecked) {
            labelsChecked = true;
            if (!scores.containsKey(LABEL_CLAP)) {
                Log.e("SnapScroll", "YAMNet labels do not include '" + LABEL_CLAP + "'; clap detection cannot work with this model");
            }
        }
        return scores;
    }

    private static float score(Map<String, Float> scores, String label) {
        if (scores == null) return 0f;
        Float v = scores.get(label);
        return v == null ? 0f : v;
    }

    private void classifyAndDispatch(double[] customFeatures, Map<String, Float> scores, long eventNs, int peak, float transientRatio) {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        if (!p.getBoolean("sound_enabled", true)) return;

        boolean clapOn = p.getBoolean("clap_on", true);
        boolean whistleOn = p.getBoolean("whistle_on", false);
        String template = p.getString("custom_feature", null);
        boolean customOn = p.getBoolean("custom_on", false) && template != null;

        double customScore = 0.0;
        if (customOn) {
            String takesRaw = p.getString("custom_takes", null);
            if (takesRaw != null) {
                for (String t : takesRaw.split(";")) {
                    customScore = Math.max(customScore, AudioFeatures.similarity(customFeatures, AudioFeatures.decode(t)));
                }
            } else {
                customScore = AudioFeatures.similarity(customFeatures, AudioFeatures.decode(template));
            }
        }
        double customThreshold = p.getFloat("custom_threshold", DEFAULT_CUSTOM_THRESHOLD);

        float clap = score(scores, LABEL_CLAP);
        float fingerSnap = score(scores, LABEL_SNAP);
        float tap = score(scores, LABEL_TAP);
        float knock = score(scores, LABEL_KNOCK);
        float slam = score(scores, LABEL_SLAM);
        float whistle = score(scores, LABEL_WHISTLE);
        float trainWhistle = score(scores, LABEL_TRAIN_WHISTLE);

        // Clapping must win against the most common look-alikes, not merely cross a loudness gate.
        boolean clapMatch = clapOn && peak >= ONSET_MIN_PEAK && transientRatio >= CLAP_MIN_TRANSIENT && clap >= 0.12f
                && clap >= fingerSnap * 1.25f
                && clap >= tap * 1.20f
                && clap >= knock * 1.20f
                && clap >= slam * 1.20f;
        boolean whistleMatch = whistleOn && whistle >= 0.22f && whistle >= trainWhistle * 1.20f;
        boolean customMatch = customOn && customScore >= customThreshold;

        // Scores from different detectors are not on the same scale, so when more than one matches
        // we use a fixed priority: your own sound, then clap, then whistle. Ambiguity is logged.
        String id;
        if (customMatch) id = "custom";
        else if (clapMatch) id = "clap";
        else if (whistleMatch) id = "whistle";
        else id = null;

        // One line per candidate so calibration can be done from logcat:
        //   adb logcat -s SnapScrollTune
        Log.i(TUNE_TAG, String.format(java.util.Locale.US,
                "peak=%d transient=%.2f clap=%.3f snap=%.3f tap=%.3f knock=%.3f slam=%.3f whistle=%.3f train=%.3f custom=%.3f thr=%.3f -> %s",
                peak, transientRatio, clap, fingerSnap, tap, knock, slam, whistle, trainWhistle,
                customScore, customThreshold, id == null ? "none" : id));
        if (id == null) return;
        int matches = (customMatch ? 1 : 0) + (clapMatch ? 1 : 0) + (whistleMatch ? 1 : 0);
        if (matches > 1) {
            Log.d("SnapScroll", "Multiple matches (" + matches + "); using " + id);
        }

        String defaultAction = "custom".equals(id) ? "down" : "clap".equals(id) ? "up" : "back";
        String doubleDefault = "custom".equals(id) ? "up" : "clap".equals(id) ? "down" : "open";
        String action = p.getString(id + "_act", defaultAction);
        String doubleAction = p.getString(id + "_double_act", doubleDefault);
        String pkg = p.getString(id + "_pkg", null);
        dispatchTimed(action, pkg, doubleAction, pkg, eventNs, p.getInt("double_delay_ms", 1000));
    }

    private void dispatchTimed(String action, String pkg, String doubleAction, String doublePkg, long nowNs, int windowMs) {
        long windowNs = Math.max(0, Math.min(2000, windowMs)) * 1_000_000L;
        if (windowNs == 0) {
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            pendingSingleNs = 0;
            ScrollAccessibilityService.perform(this, action, pkg);
            buzz(false);
            return;
        }
        if (pendingSingleNs != 0) {
            long gapMs = (nowNs - pendingSingleNs) / 1_000_000L;
            if (gapMs >= 0 && gapMs <= windowNs / 1_000_000L) {
                pendingSingleNs = 0;
                if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
                pendingSingleRunnable = null;
                getSharedPreferences("snapscroll", MODE_PRIVATE).edit().putInt("last_gap_ms", (int) gapMs).apply();
                ScrollAccessibilityService.perform(this, pendingDoubleAction, pendingDoublePackage);
                pendingAction = null;
                pendingPackage = null;
                pendingDoubleAction = null;
                pendingDoublePackage = null;
                buzz(true);
                return;
            }
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
            pendingSingleNs = 0;
            pendingAction = null;
            pendingPackage = null;
        }
        pendingSingleNs = nowNs;
        pendingAction = action;
        pendingPackage = pkg;
        pendingDoubleAction = doubleAction;
        pendingDoublePackage = doublePkg;
        final long token = nowNs;
        Runnable single = () -> {
            if (pendingSingleNs == token) {
                pendingSingleNs = 0;
                ScrollAccessibilityService.perform(this, action, pkg);
                pendingAction = null;
                pendingPackage = null;
                pendingDoubleAction = null;
                pendingDoublePackage = null;
                pendingSingleRunnable = null;
            }
        };
        pendingSingleRunnable = single;
        // The short post-roll adds recognition latency. Each clap candidate has the same
        // capture/classification path, so event timestamps still determine single vs. double.
        handler.postDelayed(single, windowMs);
        buzz(false);
    }

    private void buzz(boolean doubled) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            long[] pattern = doubled ? new long[]{0, 55, 65, 55} : new long[]{0, 28};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        } catch (Exception ignored) { }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
    }

    private void releaseClassifier() {
        if (classifierExecutor != null) {
            classifierExecutor.shutdownNow();
            classifierExecutor = null;
        }
        if (classifier != null) {
            try { classifier.close(); } catch (Exception ignored) { }
            classifier = null;
        }
    }

    private void stopMonitoring() {
        keepRunning = false;
        isRunning = false;
        session++;
        if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
        pendingSingleRunnable = null;
        if (pendingSingleNs != 0 && pendingAction != null) {
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
        }
        pendingSingleNs = 0;
        pendingAction = null;
        pendingPackage = null;
        pendingDoubleAction = null;
        pendingDoublePackage = null;

        // Stop the microphone first so the blocked read() returns, then wait for the worker
        // before releasing the recorder. Releasing while read() is running can crash.
        Thread w = worker;
        worker = null;
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
        }
        if (w != null) {
            try { w.join(800); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
        releaseRecorder();
        releaseClassifier();
        stopForeground(true);
    }

    @Override public void onDestroy() {
        stopMonitoring();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
