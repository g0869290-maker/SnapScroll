# SnapScroll 1.0 — Android project

SnapScroll is a small native Android utility prototype. It is designed for offline, on-device operation and has no account, cloud service, analytics SDK, or advertising SDK.

## Build

1. Install Android Studio on a computer.
2. Open this `SnapScroll` folder as an existing project.
3. Allow Android Studio to install the Android SDK Platform 35 and the Android Gradle Plugin / Gradle components if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

This workspace did not contain the Android SDK, Android build tools, or a working network route to download them. Therefore no APK has been compiled here. The source project is supplied instead of an unverified or fabricated APK.

## Current implementation

- Native Java Android app, minimum Android 8.0 (API 26), target API 35.
- Matches the preview: a permissions gate (microphone, notifications, accessibility, run in background), then ONE main screen: hero status ring (tap to pause/resume), expandable sound rows (Finger snap, Clap, Voice command, Your own sound) each with a toggle and an action (Scroll down / Scroll up / Go back / Open app), and a Double sound delay slider (200-800 ms). No tabs, no bottom bar.
- Foreground microphone service with the "SnapScroll is active" notification; on-device transient detector with noise-adaptive threshold.
- One sound runs the row's action; a second sound inside the delay window runs the reverse (scroll down <-> up).
- Open app: choose any launchable app per row.
- Your own sound: records 3 takes and stores a rough sharpness signature used for matching (not a trained model).
- Voice command: continuous on-device listening ("next" / "back") while the toggle is on, Android 12+ with an offline recognizer; also has a "Try a voice command" button. The mic is shared with the snap detector, so on some phones one of them may go quiet.

## Important limitations — not production-certified

The current audio engine is a **transient detector, not a trained snap/pop/clap classifier**. It cannot reliably distinguish finger snaps, finger pops, claps, speech bursts, keyboard clicks, or other sharp sounds. Its rough brightness label is diagnostic only. Do not rely on it in noisy environments or for safety-critical actions. Sound-triggered screen locking is intentionally not connected; screen lock is available only through the optional on-demand voice command.

Importing a custom sound currently stores its document URI; it does not train a model. The built-in sound profiles, calibrated custom profiles, per-app semantic navigation (e.g. next Reel/Short), reboot auto-start, and fully configurable voice phrase editor are not yet implemented. Voice commands require Android 12+ with an available on-device speech recognizer. The scrolling fallback is a generic swipe and may behave differently across apps. Android may restrict background microphone startup, especially after reboot; SnapScroll does not bypass those platform restrictions.

## First-run setup on device

1. Install the debug APK and open SnapScroll.
2. Grant microphone permission.
3. Grant notification permission for the persistent listening notification.
4. Open Android Accessibility settings and enable SnapScroll only if you want it to perform scroll gestures / screen lock.
5. Start listening from the app. Use Test Sound Mode first; it must not scroll or lock.
6. Stop listening when finished.

The microphone service must be started while the app is visible and permission is granted. Do not expect it to auto-start after reboot in this prototype.
