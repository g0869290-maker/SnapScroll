package com.snapscroll.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class ScrollAccessibilityService extends AccessibilityService {
    private static volatile ScrollAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static void performScroll(Context context, boolean up) {
        ScrollAccessibilityService s = instance;
        if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT < 24) return;
        float x = s.getResources().getDisplayMetrics().widthPixels * .5f;
        float startY = s.getResources().getDisplayMetrics().heightPixels * (up ? .35f : .72f);
        float endY = s.getResources().getDisplayMetrics().heightPixels * (up ? .72f : .35f);
        Path path = new Path(); path.moveTo(x, startY); path.lineTo(x, endY);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 260);
        s.dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }
    public static String reverse(String action) {
        if ("down".equals(action)) return "up";
        if ("up".equals(action)) return "down";
        return action;
    }

    /** Runs a configured action: down, up, back or open (launches the chosen app). */
    public static void perform(Context context, String action, String pkg) {
        if ("down".equals(action)) performScroll(context, false);
        else if ("up".equals(action)) performScroll(context, true);
        else if ("back".equals(action)) {
            ScrollAccessibilityService s = instance;
            if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
            s.performGlobalAction(GLOBAL_ACTION_BACK);
        } else if ("open".equals(action)) {
            if (pkg == null) { Toast.makeText(context, "Choose an app to open first", Toast.LENGTH_SHORT).show(); return; }
            android.content.Intent i = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (i == null) return;
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            ScrollAccessibilityService s = instance;
            try { (s != null ? (Context) s : context).startActivity(i); } catch (Exception ignored) { }
        }
    }

    public static void performLock(Context context) {
        ScrollAccessibilityService s = instance;
        if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 28) s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }
}
