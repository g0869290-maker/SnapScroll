package com.snapscroll.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.ColorStateList;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * SnapScroll UI: a permissions gate (shown until all four are granted) followed by a single
 * main screen with expandable sound rows. No tabs, no bottom bar.
 */
public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10, REQ_NOTIF = 11;
    private static final int BG = 0xFF000000, FG = 0xFFF4F4F6, SOFT = 0xFFA1A1AA;
    private static final int PURPLE = 0xFFA855F7, PURPLE2 = 0xFF7C3AED, LAV = 0xFFD8B4FE, ORANGE = 0xFFFF7A00;
    private static final int LINE = 0xFF2A2A30, GREEN = 0xFF4ADE80;

    private static final String[] ACT_LABELS = {"Scroll down", "Scroll up", "Go back", "Open app"};
    private static final String[] ACT_VALUES = {"down", "up", "back", "open"};

    // Sound rows: id, title, icon, hint, default action
    private static final String[] IDS = {"snap", "clap", "voice", "custom"};
    private static final String[] TITLES = {"Finger snap", "Clap", "Voice command", "Your own sound"};
    private static final int[] ICONS = {R.drawable.ic_snap_hand, R.drawable.ic_clap, R.drawable.ic_mic, R.drawable.ic_wave};
    private static final String[] HINTS = {
            "One snap does this. Two snaps scroll the other way.",
            "One clap does this. Two claps do the reverse.",
            "Say “next” or “back” out loud. Works offline when your phone supports it.",
            "Record any sound you like (whistle, tap, a word)."};
    private static final String[] DEF_ACT = {"down", "up", "down", "open"};
    private static final boolean[] DEF_ON = {true, true, false, false};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private SpeechRecognizer voiceRecognizer;

    private FrameLayout root;
    private ScrollView permScreen, homeScreen;
    private LinearLayout permList, rowsBox;
    private TextView permWarn, pillText, heroTitle, heroSub, delayVal;
    private Button goButton;
    private FrameLayout sheet;
    private boolean paused = false;
    private View pulse;
    private android.animation.ValueAnimator pulseAnim;
    private final boolean[] open = new boolean[4];
    private boolean recording = false, resumeAfterRecord = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("snapscroll", MODE_PRIVATE);
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshPermissions();
        if (allGranted() && permScreen.getVisibility() == View.VISIBLE) {
            showHome();
            if (!SoundMonitorService.isRunning) startListening();
        } else if (allGranted()) {
            updateStatus();
        } else {
            showPerm();
        }
    }

    // ---------- helpers ----------

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private GradientDrawable shape(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private GradientDrawable card() {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF151518, 0xFF0B0B0D});
        g.setCornerRadius(dp(24));
        g.setStroke(dp(1), LINE);
        return g;
    }

    private GradientDrawable purpleGrad(float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{PURPLE, PURPLE2});
        g.setCornerRadius(dp(r));
        return g;
    }

    private ImageView icon(int res, int sizeDp, int tint, LinearLayout parent) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        if (tint != 0) iv.setColorFilter(tint);
        parent.addView(iv, new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        return iv;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        p.bottomMargin = dp(bottom);
        return p;
    }

    private Button button(String label, boolean ghost, Runnable r) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(15);
        b.setTypeface(null, android.graphics.Typeface.BOLD);
        b.setStateListAnimator(null);
        b.setTextColor(ghost ? LAV : 0xFFFFFFFF);
        b.setBackground(ghost ? shape(0xFF17171B, 18, LINE) : purpleGrad(18));
        b.setOnClickListener(v -> r.run());
        return b;
    }

    private void styleSwitch(Switch s) {
        int[][] st = {{android.R.attr.state_checked}, {}};
        s.setTrackTintList(new ColorStateList(st, new int[]{ORANGE, 0xFF3A3A41}));
        s.setThumbTintList(new ColorStateList(st, new int[]{0xFFFFFFFF, 0xFFD0D0D6}));
    }

    private LinearLayout header() {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        icon(R.drawable.ic_snap_hand, 34, 0, h);
        LinearLayout name = new LinearLayout(this);
        name.setPadding(dp(10), 0, 0, 0);
        name.addView(text("Snap", 26, FG, true));
        final TextView scroll = text("Scroll", 26, LAV, true);
        scroll.post(() -> {
            scroll.getPaint().setShader(new LinearGradient(0, 0, scroll.getWidth(), 0, LAV, PURPLE, Shader.TileMode.CLAMP));
            scroll.invalidate();
        });
        name.addView(scroll);
        h.addView(name);
        h.setPadding(0, 0, 0, dp(18));
        return h;
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(40), dp(18), dp(30));
        return c;
    }

    private ScrollView scroller(LinearLayout c) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setVerticalScrollBarEnabled(false);
        sv.addView(c);
        return sv;
    }

    // ---------- layout ----------

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);

        // Permissions
        LinearLayout pc = column();
        pc.addView(header());
        TextView h2 = text("Allow these to start", 30, FG, true);
        pc.addView(h2, lp(-2, -2, 6, 8));
        TextView p = text("SnapScroll needs all four to hear your sounds and control the screen. Nothing is recorded or sent anywhere.", 14, SOFT, false);
        p.setLineSpacing(0, 1.2f);
        pc.addView(p, lp(-1, -2, 0, 20));
        permList = new LinearLayout(this);
        permList.setOrientation(LinearLayout.VERTICAL);
        pc.addView(permList);
        permWarn = text("Permission missing. SnapScroll stays off until every item is allowed.", 13, 0xFFFBBF24, false);
        pc.addView(permWarn, lp(-1, -2, 12, 0));
        goButton = button("Start SnapScroll", false, () -> {
            if (allGranted()) { showHome(); startListening(); }
        });
        pc.addView(goButton, lp(-1, dp(52), 12, 0));
        permScreen = scroller(pc);
        root.addView(permScreen, new FrameLayout.LayoutParams(-1, -1));

        // Main screen
        LinearLayout hc = column();
        hc.addView(header());
        hc.addView(heroCard(), lp(-1, -2, 0, 22));
        hc.addView(text("Your Sounds", 21, FG, true), lp(-2, -2, 0, 10));
        rowsBox = new LinearLayout(this);
        rowsBox.setOrientation(LinearLayout.VERTICAL);
        hc.addView(rowsBox);
        hc.addView(delayCard(), lp(-1, -2, 0, 0));
        homeScreen = scroller(hc);
        homeScreen.setVisibility(View.GONE);
        root.addView(homeScreen, new FrameLayout.LayoutParams(-1, -1));

        // Record sheet overlay
        sheet = new FrameLayout(this);
        sheet.setBackgroundColor(0xCC000000);
        sheet.setClickable(true);
        sheet.setVisibility(View.GONE);
        root.addView(sheet, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        renderPerms();
        renderRows();
    }

    private View heroCard() {
        LinearLayout card = new LinearLayout(this);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setClipChildren(false);
        card.setPadding(dp(20), dp(20), dp(16), dp(20));
        card.setBackground(card());

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        pillText = text("Listening…", 13, LAV, true);
        pillText.setBackground(shape(0xFF241A33, 99, 0));
        pillText.setPadding(dp(12), dp(6), dp(12), dp(6));
        left.addView(pillText, new LinearLayout.LayoutParams(-2, -2));
        heroTitle = text("Ready", 34, FG, true);
        left.addView(heroTitle, lp(-2, -2, 10, 4));
        heroSub = text("", 13, SOFT, false);
        left.addView(heroSub);
        card.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        FrameLayout ring = new FrameLayout(this);
        ring.setClipChildren(false);
        GradientDrawable rb = new GradientDrawable();
        rb.setShape(GradientDrawable.OVAL);
        rb.setColor(0xFF0F0A18);
        rb.setStroke(dp(3), PURPLE);
        ring.setBackground(rb);
        ImageView hand = new ImageView(this);
        hand.setImageResource(R.drawable.ic_snap_hand);
        ring.addView(hand, new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER));
        ring.setContentDescription("Pause or resume");
        pulse = new View(this);
        GradientDrawable pb = new GradientDrawable();
        pb.setShape(GradientDrawable.OVAL);
        pb.setStroke(dp(2), PURPLE);
        pb.setColor(0);
        pulse.setBackground(pb);
        ring.addView(pulse, new FrameLayout.LayoutParams(-1, -1));
        pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f);
        pulseAnim.setDuration(2000);
        pulseAnim.setRepeatCount(android.animation.ValueAnimator.INFINITE);
        pulseAnim.addUpdateListener(a -> {
            float f = (float) a.getAnimatedValue();
            pulse.setScaleX(1f + .28f * f); pulse.setScaleY(1f + .28f * f); pulse.setAlpha(.7f * (1f - f));
        });
        ring.setOnClickListener(v -> toggleListening());
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(dp(112), dp(112));
        rp.leftMargin = dp(10);
        card.addView(ring, rp);
        return card;
    }

    private View delayCard() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        c.setBackground(card());
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(text("Double sound delay", 15, FG, true));
        tx.addView(text("Wait briefly for a second sound", 12.5f, SOFT, false));
        top.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
        delayVal = text("", 14, FG, true);
        delayVal.setBackground(shape(0, 99, LINE));
        delayVal.setPadding(dp(12), dp(6), dp(12), dp(6));
        top.addView(delayVal);
        c.addView(top);
        SeekBar sb = new SeekBar(this);
        sb.setMax(12);
        sb.setProgress((prefs.getInt("double_delay_ms", 400) - 200) / 50);
        sb.setProgressTintList(ColorStateList.valueOf(PURPLE));
        sb.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                int ms = 200 + progress * 50;
                delayVal.setText(ms + " ms");
                if (fromUser) prefs.edit().putInt("double_delay_ms", ms).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        c.addView(sb, lp(-1, -2, 12, 0));
        delayVal.setText(prefs.getInt("double_delay_ms", 400) + " ms");
        return c;
    }

    // ---------- permissions ----------

    private boolean hasMic() { return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED; }

    private boolean hasNotif() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            return false;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        return nm == null || nm.areNotificationsEnabled();
    }

    private boolean hasAccessibility() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled != null && enabled.toLowerCase(Locale.ROOT).contains((getPackageName() + "/").toLowerCase(Locale.ROOT));
    }

    private boolean hasBattery() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private boolean[] permState() { return new boolean[]{hasMic(), hasNotif(), hasAccessibility(), hasBattery()}; }

    private boolean allGranted() {
        for (boolean b : permState()) if (!b) return false;
        return true;
    }

    private void refreshPermissions() { renderPerms(); }

    private void renderPerms() {
        String[] titles = {"Microphone", "Notifications", "Accessibility", "Run in background"};
        String[] descs = {"Hear your snap, clap and voice.", "Shows “SnapScroll is active” while listening.",
                "Lets SnapScroll swipe and tap in any app.", "Stops your phone from switching it off."};
        int[] icons = {R.drawable.ic_mic, R.drawable.ic_bell, R.drawable.ic_snap_hand, R.drawable.ic_battery};
        boolean[] st = permState();
        permList.removeAllViews();
        boolean any = false, all = true;
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            any |= st[i];
            all &= st[i];
            LinearLayout r = new LinearLayout(this);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.setPadding(dp(14), dp(14), dp(14), dp(14));
            r.setBackground(card());
            LinearLayout dot = new LinearLayout(this);
            dot.setGravity(Gravity.CENTER);
            dot.setBackground(shape(0xFF241A33, 12, 0));
            icon(icons[i], 20, (i==0||i==2) ? 0 : LAV, dot);
            r.addView(dot, new LinearLayout.LayoutParams(dp(38), dp(38)));
            LinearLayout tx = new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.setPadding(dp(12), 0, dp(8), 0);
            tx.addView(text(titles[i], 15, FG, true));
            tx.addView(text(descs[i], 12, SOFT, false));
            r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));
            Button a = new Button(this);
            a.setAllCaps(false);
            a.setStateListAnimator(null);
            a.setTextSize(13);
            a.setMinHeight(0);
            a.setMinimumHeight(0);
            a.setPadding(dp(14), dp(9), dp(14), dp(9));
            if (st[i]) {
                a.setText("Allowed ✓");
                a.setTextColor(GREEN);
                a.setBackground(shape(0xFF14301F, 99, 0));
                a.setEnabled(false);
            } else {
                a.setText("Allow");
                a.setTextColor(0xFFFFFFFF);
                a.setBackground(shape(PURPLE2, 99, 0));
                a.setOnClickListener(v -> requestPerm(idx));
            }
            r.addView(a, new LinearLayout.LayoutParams(-2, dp(38)));
            permList.addView(r, lp(-1, -2, 0, 10));
        }
        permWarn.setVisibility(!all && any ? View.VISIBLE : View.GONE);
        goButton.setEnabled(all);
        goButton.setAlpha(all ? 1f : .4f);
    }

    private void requestPerm(int idx) {
        switch (idx) {
            case 0:
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
                break;
            case 1:
                if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
                else
                    startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
                break;
            case 2:
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                toast("Find SnapScroll in the list and turn it on");
                break;
            default:
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
        }
    }

    @Override public void onRequestPermissionsResult(int request, String[] perms, int[] results) {
        super.onRequestPermissionsResult(request, perms, results);
        renderPerms();
        if (allGranted() && permScreen.getVisibility() == View.VISIBLE) { showHome(); startListening(); }
    }

    private void showPerm() {
        permScreen.setVisibility(View.VISIBLE);
        homeScreen.setVisibility(View.GONE);
    }

    private void showHome() {
        permScreen.setVisibility(View.GONE);
        homeScreen.setVisibility(View.VISIBLE);
        updateStatus();
    }

    // ---------- sound rows ----------

    private boolean soundOn(int i) { return prefs.getBoolean(IDS[i] + "_on", DEF_ON[i]); }

    private String act(int i) { return prefs.getString(IDS[i] + "_act", DEF_ACT[i]); }

    private String actLabel(String v) {
        for (int i = 0; i < ACT_VALUES.length; i++) if (ACT_VALUES[i].equals(v)) return ACT_LABELS[i];
        return v;
    }

    private String appLabel(int i) {
        String pkg = prefs.getString(IDS[i] + "_pkg", null);
        if (pkg == null) return null;
        try {
            return getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(pkg, 0)).toString();
        } catch (Exception e) { return null; }
    }

    private void syncMaster() {
        // The listener service acts on sound rows only (voice is on-demand).
        boolean any = soundOn(0) || soundOn(1) || soundOn(3);
        prefs.edit().putBoolean("sound_enabled", any).apply();
    }

    private void renderRows() {
        rowsBox.removeAllViews();
        boolean hasCustom = prefs.getString("custom_name", null) != null;
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            LinearLayout rowCard = new LinearLayout(this);
            rowCard.setOrientation(LinearLayout.VERTICAL);
            rowCard.setBackground(card());

            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setPadding(dp(16), dp(14), dp(14), dp(14));
            icon(ICONS[i], 40, 0, top);
            LinearLayout tx = new LinearLayout(this);
            tx.setOrientation(LinearLayout.VERTICAL);
            tx.setPadding(dp(14), 0, dp(8), 0);
            String title = (i == 3 && hasCustom) ? prefs.getString("custom_name", TITLES[3]) : TITLES[i];
            tx.addView(text(title, 17, FG, true));
            String sub = (i == 3 && !hasCustom) ? "Not added yet" : actLabel(act(i));
            if ("open".equals(act(i)) && appLabel(i) != null && !(i == 3 && !hasCustom)) sub += " · " + appLabel(i);
            tx.addView(text(sub, 13, SOFT, false));
            top.addView(tx, new LinearLayout.LayoutParams(0, -2, 1f));

            Switch sw = new Switch(this);
            styleSwitch(sw);
            sw.setChecked(soundOn(i));
            sw.setContentDescription("Turn " + TITLES[i] + " on or off");
            sw.setOnClickListener(v -> {
                boolean want = sw.isChecked();
                if (idx == 3 && want && prefs.getString("custom_name", null) == null) {
                    sw.setChecked(false);
                    openRecordSheet();
                    return;
                }
                prefs.edit().putBoolean(IDS[idx] + "_on", want).apply();
                syncMaster();
                if (idx == 2 && SoundMonitorService.isRunning) startListening();
                renderRows();
            });
            top.addView(sw);
            ImageView chev = new ImageView(this);
            chev.setImageResource(R.drawable.ic_chevron);
            chev.setColorFilter(SOFT);
            chev.setRotation(open[i] ? 90 : 0);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(18), dp(18));
            cp.leftMargin = dp(10);
            top.addView(chev, cp);
            top.setOnClickListener(v -> { open[idx] = !open[idx]; renderRows(); });
            rowCard.addView(top);

            if (open[i]) {
                LinearLayout more = new LinearLayout(this);
                more.setOrientation(LinearLayout.VERTICAL);
                more.setPadding(dp(16), 0, dp(16), dp(16));
                more.addView(text(HINTS[i], 12.5f, SOFT, false), lp(-1, -2, 2, 8));
                LinearLayout line1 = new LinearLayout(this), line2 = new LinearLayout(this);
                for (int a = 0; a < 4; a++) {
                    final String val = ACT_VALUES[a];
                    TextView chip = text(ACT_LABELS[a], 13, FG, false);
                    chip.setGravity(Gravity.CENTER);
                    chip.setPadding(dp(8), dp(9), dp(8), dp(9));
                    boolean on = val.equals(act(i));
                    chip.setBackground(on ? purpleGrad(99) : shape(0xFF101013, 99, LINE));
                    if (on) chip.setTypeface(null, android.graphics.Typeface.BOLD);
                    chip.setOnClickListener(v -> {
                        prefs.edit().putString(IDS[idx] + "_act", val).apply();
                        if ("open".equals(val) && prefs.getString(IDS[idx] + "_pkg", null) == null) pickApp(idx);
                        renderRows();
                    });
                    LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(0, -2, 1f);
                    cp2.setMargins(dp(3), dp(3), dp(3), dp(3));
                    (a < 2 ? line1 : line2).addView(chip, cp2);
                }
                more.addView(line1);
                more.addView(line2);
                if ("open".equals(act(i)))
                    more.addView(button(appLabel(i) == null ? "Choose app" : "App: " + appLabel(i) + " (change)", true, () -> pickApp(idx)), lp(-1, dp(48), 8, 0));
                if (i == 2)
                    more.addView(button("Try a voice command", true, this::voiceCommand), lp(-1, dp(48), 8, 0));
                if (i == 3)
                    more.addView(button(hasCustom ? "Record again" : "Record your sound", true, this::openRecordSheet), lp(-1, dp(48), 8, 0));
                rowCard.addView(more);
            }
            rowsBox.addView(rowCard, lp(-1, -2, 0, 10));
        }
    }

    private void pickApp(int idx) {
        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
        final List<String> pkgs = new ArrayList<>();
        final List<String> names = new ArrayList<>();
        java.util.Collections.sort(apps, new ResolveInfo.DisplayNameComparator(pm));
        for (ResolveInfo ri : apps) {
            if (ri.activityInfo.packageName.equals(getPackageName())) continue;
            pkgs.add(ri.activityInfo.packageName);
            names.add(ri.loadLabel(pm).toString());
        }
        if (names.isEmpty()) { toast("No apps found"); return; }
        new AlertDialog.Builder(this).setTitle("Open which app?")
                .setItems(names.toArray(new String[0]), (d, which) -> {
                    prefs.edit().putString(IDS[idx] + "_pkg", pkgs.get(which)).apply();
                    renderRows();
                }).show();
    }

    // ---------- record custom sound ----------

    private int takes = 0;
    private final int[] takeZcr = new int[3];

    private void openRecordSheet() {
        takes = 0;
        resumeAfterRecord = SoundMonitorService.isRunning;
        if (resumeAfterRecord) stopListening();
        drawSheet(false);
        sheet.setVisibility(View.VISIBLE);
    }

    private void closeSheet() {
        sheet.setVisibility(View.GONE);
        recording = false;
        if (resumeAfterRecord) { resumeAfterRecord = false; ui.postDelayed(this::startListening, 300); }
    }

    private void drawSheet(boolean listening) {
        sheet.removeAllViews();
        LinearLayout in = new LinearLayout(this);
        in.setOrientation(LinearLayout.VERTICAL);
        in.setPadding(dp(18), dp(22), dp(18), dp(26));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF131317);
        bg.setStroke(dp(1), LINE);
        bg.setCornerRadii(new float[]{dp(28), dp(28), dp(28), dp(28), 0, 0, 0, 0});
        in.setBackground(bg);
        in.addView(text("Record your sound", 19, FG, true));
        TextView p = text("Make the sound 3 times, about a second apart. Keep it the same each time.", 13, SOFT, false);
        in.addView(p, lp(-1, -2, 4, 10));
        LinearLayout bars = new LinearLayout(this);
        for (int i = 0; i < 3; i++) {
            View b = new View(this);
            b.setBackground(shape(i < takes ? PURPLE : 0xFF26262C, 9, 0));
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(8), 1f);
            bp.setMargins(dp(4), dp(6), dp(4), dp(4));
            bars.addView(b, bp);
        }
        in.addView(bars);
        String label = listening ? "Listening…" : takes >= 3 ? "Save sound" : "Record take " + (takes + 1) + " of 3";
        Button rb = button(label, false, () -> {
            if (recording) return;
            if (takes >= 3) { saveCustom(); return; }
            captureTake();
        });
        rb.setEnabled(!listening);
        in.addView(rb, lp(-1, dp(52), 12, 0));
        in.addView(button("Cancel", true, this::closeSheet), lp(-1, dp(52), 10, 0));
        sheet.addView(in, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
    }

    private void captureTake() {
        if (!hasMic()) { toast("Microphone permission needed"); return; }
        recording = true;
        drawSheet(true);
        new Thread(() -> {
            int zcr = -1;
            AudioRecord rec = null;
            try {
                int rate = 16000;
                int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate));
                if (rec.getState() == AudioRecord.STATE_INITIALIZED) {
                    rec.startRecording();
                    short[] d = new short[320];
                    long end = System.currentTimeMillis() + 1500;
                    int bestPeak = 0;
                    while (System.currentTimeMillis() < end) {
                        int n = rec.read(d, 0, d.length);
                        if (n <= 0) continue;
                        int peak = 0, cross = 0;
                        short prev = d[0];
                        for (int i = 0; i < n; i++) {
                            peak = Math.max(peak, Math.abs(d[i]));
                            if ((d[i] >= 0 && prev < 0) || (d[i] < 0 && prev >= 0)) cross++;
                            prev = d[i];
                        }
                        if (peak > bestPeak) { bestPeak = peak; zcr = cross; }
                    }
                    if (bestPeak < 2000) zcr = -1;
                }
            } catch (Exception ignored) {
            } finally {
                if (rec != null) { try { rec.stop(); } catch (Exception ignored) { } rec.release(); }
            }
            final int result = zcr;
            ui.post(() -> {
                recording = false;
                if (result < 0) toast("Didn’t hear that. Try again a bit louder.");
                else takeZcr[takes++] = result;
                drawSheet(false);
            });
        }, "SnapScroll-Record").start();
    }

    private void saveCustom() {
        int sum = takeZcr[0] + takeZcr[1] + takeZcr[2];
        prefs.edit().putString("custom_name", "Your sound").putInt("custom_zcr", sum / 3).putBoolean("custom_on", true).apply();
        syncMaster();
        sheet.setVisibility(View.GONE);
        if (resumeAfterRecord) { resumeAfterRecord = false; ui.postDelayed(this::startListening, 300); }
        renderRows();
        toast("Sound saved");
    }

    // ---------- listening ----------

    private void toggleListening() {
        if (SoundMonitorService.isRunning) { paused = true; stopListening(); } else { paused = false; startListening(); }
    }

    private void updateStatus() {
        if (heroTitle == null) return;
        boolean running = SoundMonitorService.isRunning;
        pillText.setText(running ? "●  Listening…" : "●  Paused");
        pillText.setTextColor(running ? LAV : SOFT);
        heroTitle.setText(running ? "Ready" : "Paused");
        if (pulseAnim != null) { if (running) { if (!pulseAnim.isStarted()) pulseAnim.start(); } else { pulseAnim.cancel(); pulse.setAlpha(0); } }
        heroSub.setText(running ? "Snap, clap or speak to control your phone in any app."
                : "Tap the ring to start listening again.");
    }

    private void startListening() {
        if (!hasMic()) { requestPerm(0); return; }
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        ui.postDelayed(this::updateStatus, 600);
    }

    private void stopListening() {
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_STOP);
        startService(i);
        SoundMonitorService.isRunning = false;
        updateStatus();
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    // ---------- voice (on demand, on-device only) ----------

    private void voiceCommand() {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            Toast.makeText(this, "On-device voice recognition isn’t available on this phone. SnapScroll won’t use an online fallback.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!hasMic()) { requestPerm(0); return; }
        try {
            if (voiceRecognizer != null) voiceRecognizer.destroy();
            voiceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            voiceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { toast("Say “next” or “back”…"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) { toast("Voice recognition ended (code " + error + ")"); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> m = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (m != null && !m.isEmpty()) runVoiceAction(m.get(0));
                    if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            voiceRecognizer.startListening(intent);
        } catch (Exception e) {
            if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
            toast("On-device voice recognition could not start");
        }
    }

    private void runVoiceAction(String phrase) {
        String s = phrase.toLowerCase(Locale.ROOT);
        String main = act(2);
        String pkg = prefs.getString("voice_pkg", null);
        if (s.contains("next") || s.contains("scroll down")) ScrollAccessibilityService.perform(this, main, pkg);
        else if (s.contains("back") || s.contains("previous") || s.contains("scroll up"))
            ScrollAccessibilityService.perform(this, ScrollAccessibilityService.reverse(main), pkg);
        else toast("Command not recognised: " + phrase);
    }

    @Override protected void onDestroy() {
        if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
        super.onDestroy();
    }
}
