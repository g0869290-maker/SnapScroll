# SnapScroll 1.4.3 (reliability and cleanup update)

This update preserves the compact version 1.4 interface and its existing controls. It has exactly two sound triggers: **Your sound** and **Clap**. Whistle is not included. Audio is processed locally; raw microphone audio is not saved or uploaded.

## What changed in 1.4.3
- **Much stricter "Your sound" matching (re-record once).** Your sound is now a temporal fingerprint: 12 frequency bands over three slices of the sound plus its loudness shape, so a hand tap, table knock, key click, speech or cough no longer looks like your sound just because their average spectrum is similar. The match threshold is set from how consistent your own three takes are, and the sound's length must also be close to your takes. On a PC test with synthetic sounds, false accepts of other sounds fell from about 37% to about 8% while missed real sounds stayed under 4%. Real phones differ, so treat these as relative, not absolute, numbers.
- **Match score on screen.** The status card shows "Your sound detected · NN% match", or "Heard a similar sound · NN% match, needs MM%" when something close was rejected, so you can see why a sound did or did not trigger.
- Recordings made in 1.4.2 keep working with the old matcher; the row says "Re-record for better accuracy" until you re-record.
- **Enrollment now matches runtime.** Taught sounds used to be cut and fingerprinted differently from sounds heard in the background. Both now use one shared `SoundDetector`, so your three takes are comparable with what the service hears. Existing saved fingerprints still work (feature output verified bit-identical to 1.4.2).
- **Inconsistent takes are rejected.** If the three takes don't resemble each other, you are asked to re-record instead of saving an unusable sound.
- **No false "microphone read failed" on pause.** Pausing released the microphone under the reading thread, which could record a spurious error and stop the service state out of sync.
- **Stale pre-roll fixed.** Audio from before a previous event could leak into the next one; the pre-roll is now cleared after each event.
- **Foreground service type declared at runtime** (microphone) on Android 10+, as newer Android versions expect.
- **Pause button in the notification** and the app's own icon instead of a system placeholder.
- **Faster fingerprinting**: the Hamming window is computed once, not eight times per sample.
- **Smaller, quieter build**: release builds are minified and resource-shrunk; the Accessibility service no longer subscribes to events it ignores; unused speech-recognition query and dead code removed.
- **CI** runs a dependency-free JVM test of the detector (`tests/DetectorSanityTest.java`) and builds the release APK as well.

## Kept controls
- Independent enable switches for Your sound and Clap
- Separate one-sound and two-sound actions for each trigger
- Scroll down, Scroll up, Go back, Open app, Lock screen and Wake screen
- Configurable 0–2,000 ms double-sound window (0 means single-only)
- Three-take enrollment for Your sound
- Accessibility service for cross-app gestures and lock-screen action

## Reliability changes
- Fixed a crash in the master sound-enable update: it previously referenced a nonexistent third trigger.
- Reduced the event debounce from 180 ms to 65 ms so two distinct claps closer together are not discarded.
- Relaxed the adaptive sound onset gate while retaining peak and spectral checks.
- Added a 40 ms pre-roll buffer so the start of a clap or enrolled sound is not clipped by the detector.
- Enrolled Your Sound now keeps the three takes as separate templates and matches against the best take instead of averaging away differences between takes. Existing saved fingerprints remain supported.
- Shortened quiet-tail detection slightly and adjusted the adaptive gate to help quieter, clean sounds register.
- Clap threshold is modestly stricter than the previous tuning to reduce incidental clicks while preserving the more responsive onset gate.
- Widened the event-duration range and modestly relaxed recognition thresholds to reduce missed single sounds.
- Added immediate in-app feedback: sound detected, first sound waiting for second, single recognized, or double recognized with measured gap.

## Double-sound behavior
The first recognized event starts the selected timing window. A second recognized event inside that window cancels the pending single action and runs the double action immediately. If no second event arrives, the single action runs when the window expires. The minimum debounce is 65 ms to avoid treating one impact as multiple events while allowing faster pairs.

## Notifications and microphone privacy indicator
Notification permission remains optional. On Android 13 and newer, denying notification permission can hide the foreground-service notification from the notification shade, but Android may still show the service in its active-app/Task Manager area. Android's green microphone privacy indicator is controlled by the operating system and cannot be hidden by an app while the microphone is active. The app must provide a foreground-service notification while it listens in the background.

## Recognition limitations
This remains a lightweight signal-processing recognizer to preserve the small app size; it is not a trained neural-network classifier. Very similar sounds (for example, a sharp mouth click and a small impact) can still be confused. The wider thresholds reduce missed events but may increase false positives depending on the phone microphone and room.

## Build and test status
`AudioFeatures` and `SoundDetector` are plain Java and were compiled and exercised on a JVM with synthetic audio (`tests/DetectorSanityTest.java`). The Android code was only syntax-checked: it has **not** been compiled with the Android SDK or tested on a physical phone. Release builds are unsigned; sign them with your own keystore. Test Clap and Your Sound on the target device, with the phone at the intended distance, and check the immediate status feedback before relying on configured actions.
