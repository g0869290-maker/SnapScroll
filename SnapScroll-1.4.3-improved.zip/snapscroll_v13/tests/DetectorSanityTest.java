package com.snapscroll.app;

import java.util.Random;

/** Dependency-free JVM check: noise is ignored, bursts are found once, features are stable. */
public class DetectorSanityTest {
    static final int RATE = 16000;

    static short[] stream(double noise, double[] burst, double peak, Random r) {
        int lead = RATE / 2, n = lead + (burst == null ? 0 : burst.length) + RATE / 2;
        short[] pcm = new short[n];
        double mx = 1; if (burst != null) for (double v : burst) mx = Math.max(mx, Math.abs(v));
        for (int i = 0; i < n; i++) {
            double v = r.nextGaussian() * noise;
            if (burst != null && i >= lead && i < lead + burst.length) v += burst[i - lead] / mx * peak;
            pcm[i] = (short) Math.max(-32768, Math.min(32767, Math.round(v)));
        }
        return pcm;
    }

    static int count(short[] pcm, double[][] firstFeatures) {
        SoundDetector d = new SoundDetector();
        short[] f = new short[SoundDetector.FRAME];
        int events = 0;
        for (int o = 0; o + f.length <= pcm.length; o += f.length) {
            System.arraycopy(pcm, o, f, 0, f.length);
            SoundDetector.Event e = d.feed(f, f.length);
            if (e != null) { if (events++ == 0 && firstFeatures != null) firstFeatures[0] = e.features; }
        }
        return events;
    }

    static SoundDetector.Event firstEvent(short[] pcm) {
        SoundDetector d = new SoundDetector();
        short[] f = new short[SoundDetector.FRAME];
        for (int o = 0; o + f.length <= pcm.length; o += f.length) {
            System.arraycopy(pcm, o, f, 0, f.length);
            SoundDetector.Event e = d.feed(f, f.length);
            if (e != null) return e;
        }
        return null;
    }

    static void check(boolean ok, String msg) {
        if (!ok) { System.err.println("FAIL: " + msg); System.exit(1); }
        System.out.println("ok: " + msg);
    }

    public static void main(String[] args) {
        Random r = new Random(1);
        check(count(stream(20, null, 0, r), null) == 0, "steady background noise produces no events");

        double[] clap = new double[800];
        for (int i = 0; i < clap.length; i++) clap[i] = r.nextGaussian() * Math.exp(-i / 140.0);
        double[][] a = new double[1][], b = new double[1][];
        check(count(stream(15, clap, 9000, r), a) == 1, "one clap produces exactly one event");
        check(count(stream(15, clap, 9000, r), b) == 1, "second clap produces exactly one event");
        check(AudioFeatures.similarity(a[0], b[0]) > 0.83, "two claps fingerprint as the same sound");

        // v2 temporal fingerprint: a clap matches another clap far better than a low thump (hand tap).
        double[] tap = new double[500]; double lp = 0;
        for (int i = 0; i < tap.length; i++) { lp += 0.1 * (r.nextGaussian() - lp); tap[i] = lp * 6 * Math.exp(-i / 110.0); }
        SoundDetector.Event c1 = firstEvent(stream(15, clap, 9000, r)), c2 = firstEvent(stream(15, clap, 9000, r)), t1 = firstEvent(stream(15, tap, 9000, r));
        check(c1 != null && c2 != null && t1 != null, "clap and tap are both detected");
        double same = AudioFeatures.similarityV2(c1.featuresV2, c2.featuresV2), diff = AudioFeatures.similarityV2(c1.featuresV2, t1.featuresV2);
        check(same - diff > 0.10, String.format("v2: clap~clap %.2f clearly above clap~tap %.2f", same, diff));
        check(AudioFeatures.decodeV2(AudioFeatures.encodeV2(c1.featuresV2)) != null, "v2 fingerprint round-trips through storage encoding");

        // Two bursts 300 ms apart must stay two events (pre-roll must not leak across events).
        short[] one = stream(15, clap, 9000, r);
        short[] pair = new short[one.length + 4800 + 2 * RATE / 2];
        System.arraycopy(one, 0, pair, 0, one.length - RATE / 2);
        int second = one.length - RATE / 2 + 4800;
        for (int i = 0; i < pair.length; i++) if (i >= one.length - RATE / 2 && i < second) pair[i] = (short) (r.nextGaussian() * 15);
        short[] tail = stream(15, clap, 9000, r);
        System.arraycopy(tail, RATE / 2 - 0, pair, second, Math.min(tail.length - RATE / 2, pair.length - second));
        check(count(pair, null) == 2, "two claps 300 ms apart give two events");
    }
}
