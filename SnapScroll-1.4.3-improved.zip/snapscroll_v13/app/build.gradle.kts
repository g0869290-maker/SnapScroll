plugins { id("com.android.application") }

android {
    namespace = "com.snapscroll.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.snapscroll.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "1.4.3"
    }
    buildTypes {
        release {
            // Unsigned by default; sign with your own keystore before installing/distributing.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
