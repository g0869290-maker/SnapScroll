package com.snapscroll.app;

/**
 * Pure-Java transient detector shared by the background service and the enrollment sheet, so a
 * sound is cut out and fingerprinted identically when it is taught and when it is heard.
 * Feed it consecutive 16 kHz mono frames; it returns an {@link Event} once a sound has ended.
 */
final class SoundDetector {
    static final int FRAME = 160;               // 10 ms at 16 kHz
    private static final int MAX_FRAMES = 80;   // 800 ms cap per event
    private static final int PRE_ROLL = FRAME * 4;
    private static final int WINDOW = 1280;     // 80 ms analysis window

    static final class Event {
        final double[] features;
        final int durationFrames;
        final double[] featuresV2;
        final int peak;
        Event(double[] features, double[] featuresV2, int durationFrames, int peak) {
            this.features = features; this.featuresV2 = featuresV2; this.durationFrames = durationFrames; this.peak = peak;
        }
    }

    private final short[] event = new short[FRAME * MAX_FRAMES];
    private final short[] preRoll = new short[PRE_ROLL];
    private int eventLength, quietFrames, preWrite, preCount;
    private boolean inEvent;
    private double noiseRms = 28.0;

    void reset() {
        eventLength = quietFrames = preWrite = preCount = 0;
        inEvent = false;
        noiseRms = 28.0;
    }

    /** @return a finished event, or null while idle / still inside a sound. */
    Event feed(short[] frame, int n) {
        if (n <= 0) return null;
        double sum = 0; int peak = 0;
        for (int i = 0; i < n; i++) { int v = frame[i]; sum += (double) v * v; peak = Math.max(peak, Math.abs(v)); }
        double rms = Math.sqrt(sum / n);
        if (!inEvent) {
            noiseRms = noiseRms * 0.985 + Math.min(rms, noiseRms * 2.0) * 0.015;
            double gate = Math.max(62.0, noiseRms * 2.45);
            if (rms > gate && peak > 320 && peak > rms * 1.28) {
                inEvent = true; quietFrames = 0;
                int start = (preWrite - preCount + PRE_ROLL) % PRE_ROLL;
                int first = Math.min(preCount, PRE_ROLL - start);
                System.arraycopy(preRoll, start, event, 0, first);
                if (first < preCount) System.arraycopy(preRoll, 0, event, first, preCount - first);
                eventLength = preCount;
            } else {
                int first = Math.min(n, PRE_ROLL - preWrite);
                System.arraycopy(frame, 0, preRoll, preWrite, first);
                if (first < n) System.arraycopy(frame, first, preRoll, 0, n - first);
                preWrite = (preWrite + n) % PRE_ROLL;
                preCount = Math.min(PRE_ROLL, preCount + n);
            }
        }
        if (!inEvent) return null;

        int copy = Math.min(n, event.length - eventLength);
        if (copy > 0) { System.arraycopy(frame, 0, event, eventLength, copy); eventLength += copy; }
        if (rms < Math.max(48.0, noiseRms * 1.55)) quietFrames++; else quietFrames = 0;
        if (quietFrames < 3 && eventLength < event.length) return null;

        inEvent = false;
        preCount = 0; // the pre-roll now holds stale audio from before this event
        int len = eventLength;
        eventLength = 0; quietFrames = 0;
        if (len < FRAME) return null;
        return finish(len);
    }

    private Event finish(int len) {
        int bestStart = 0, bestPeak = 0;
        for (int start = 0; start + FRAME <= len; start += FRAME / 2) {
            int local = 0;
            for (int j = start; j < start + FRAME; j++) local = Math.max(local, Math.abs(event[j]));
            if (local > bestPeak) { bestPeak = local; bestStart = start; }
        }
        // 80 ms window starting ~30 ms before the loudest block gives repeatable spectral context.
        int from = Math.max(0, Math.min(bestStart - 480, Math.max(0, len - WINDOW)));
        int count = Math.min(WINDOW, len - from);
        short[] window = new short[count];
        System.arraycopy(event, from, window, 0, count);
        return new Event(AudioFeatures.extract(window, count), AudioFeatures.extractV2(window, count), len / FRAME, bestPeak);
    }
}
