package com.snapscroll.app;

/** Small on-device acoustic fingerprint helper. No audio is stored or uploaded. */
final class AudioFeatures {
    private static final double[] FREQS = {250, 450, 700, 1000, 1400, 1900, 2600, 3600};
    private static final int RATE = 16000;
    private AudioFeatures() {}

    static double[] extract(short[] samples, int length) {
        int n = Math.min(length, samples.length);
        double[] out = new double[9];
        if (n < 40) return out;
        int crossings = 0;
        short prev = samples[0];
        double peak = 0, sumSq = 0;
        for (int i = 0; i < n; i++) {
            double v = samples[i];
            peak = Math.max(peak, Math.abs(v));
            sumSq += v * v;
            if ((samples[i] >= 0 && prev < 0) || (samples[i] < 0 && prev >= 0)) crossings++;
            prev = samples[i];
        }
        double rms = Math.sqrt(sumSq / n);
        if (rms < 1) return out;
        double[] win = new double[n]; // computed once, not once per band and sample
        for (int i = 0; i < n; i++) win[i] = 0.54 - 0.46 * Math.cos(2.0 * Math.PI * i / Math.max(1, n - 1));
        double total = 0;
        for (int b = 0; b < FREQS.length; b++) {
            double omega = 2.0 * Math.PI * FREQS[b] / RATE;
            double coeff = 2.0 * Math.cos(omega), s1 = 0, s2 = 0;
            for (int i = 0; i < n; i++) {
                double x = samples[i] * win[i];
                double s0 = x + coeff * s1 - s2;
                s2 = s1; s1 = s0;
            }
            double power = Math.max(0, s1 * s1 + s2 * s2 - coeff * s1 * s2);
            out[b] = Math.sqrt(power);
            total += out[b];
        }
        if (total > 0) for (int i = 0; i < 8; i++) out[i] /= total;
        out[8] = (double) crossings / n;
        return out;
    }

    static String encode(double[] f) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < f.length; i++) {
            if (i > 0) b.append(',');
            b.append(String.format(java.util.Locale.US, "%.6f", f[i]));
        }
        return b.toString();
    }

    static double[] decode(String s) {
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length != 9) return null;
            double[] f = new double[9];
            for (int i = 0; i < 9; i++) f[i] = Double.parseDouble(p[i]);
            return f;
        } catch (Exception e) { return null; }
    }

    static double similarity(double[] a, double[] b) {
        if (a == null || b == null) return 0;
        double dot = 0, aa = 0, bb = 0;
        for (int i = 0; i < 9; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        return aa <= 0 || bb <= 0 ? 0 : dot / Math.sqrt(aa * bb);
    }


    /** Lowest similarity between any two enrollment takes; low means the takes were inconsistent. */
    static double minPairwise(double[][] takes) {
        double min = 1;
        for (int i = 0; i < takes.length; i++)
            for (int j = i + 1; j < takes.length; j++) min = Math.min(min, similarity(takes[i], takes[j]));
        return min;
    }

    /** Best match across separately enrolled takes; avoids averaging away natural variation. */
    static double maxSimilarity(double[] sample, String encodedTakes, double[] fallback) {
        double best = fallback == null ? 0 : similarity(sample, fallback);
        if (encodedTakes == null || encodedTakes.isEmpty()) return best;
        String[] takes = encodedTakes.split("\\|");
        for (String take : takes) {
            double score = similarity(sample, decode(take));
            if (score > best) best = score;
        }
        return best;
    }

    /** Spectral spread and zero-crossing score for a short broadband clap transient. */
    static double clapScore(double[] f) {
        if (f == null || f.length < 9) return 0;
        double entropy = 0, centroid = 0, maxBand = 0;
        for (int i = 0; i < 8; i++) {
            double p = f[i];
            if (p > 0.0001) entropy -= p * Math.log(p);
            centroid += p * FREQS[i];
            maxBand = Math.max(maxBand, p);
        }
        entropy /= Math.log(8.0);
        double broad = Math.max(0, Math.min(1, (entropy - 0.38) / 0.50));
        double midHigh = Math.max(0, Math.min(1, (centroid - 700.0) / 2200.0));
        double notTonal = 1.0 - Math.max(0, Math.min(1, (maxBand - 0.28) / 0.62));
        double zcr = Math.max(0, Math.min(1, 1.0 - Math.abs(f[8] - 0.22) / 0.38));
        return 0.48 * broad + 0.24 * midHigh + 0.18 * notTonal + 0.10 * zcr;
    }

    // ---------- v2 fingerprint: 3 time slices x 12 bands, plus per-slice zero-crossings and envelope ----------
    private static final double[] FREQS2 = {200, 300, 450, 600, 800, 1000, 1300, 1700, 2200, 2800, 3600, 4800};
    static final int V2_LEN = 3 * 12 + 3 + 3;

    /** Temporal fingerprint. Separates sounds that share an average spectrum but differ in how they evolve. */
    static double[] extractV2(short[] samples, int length) {
        int n = Math.min(length, samples.length);
        double[] out = new double[V2_LEN];
        if (n < 240) return out;
        int seg = n / 3;
        double[] rms = new double[3];
        for (int sl = 0; sl < 3; sl++) {
            int from = sl * seg, to = sl == 2 ? n : from + seg, len = to - from;
            double sq = 0; int cross = 0;
            for (int i = from; i < to; i++) {
                sq += (double) samples[i] * samples[i];
                if (i > from && ((samples[i] >= 0) != (samples[i - 1] >= 0))) cross++;
            }
            rms[sl] = Math.sqrt(sq / len);
            out[36 + sl] = (double) cross / len;
            if (rms[sl] < 1) continue;
            double[] win = new double[len];
            for (int i = 0; i < len; i++) win[i] = 0.54 - 0.46 * Math.cos(2.0 * Math.PI * i / Math.max(1, len - 1));
            double total = 0;
            double[] mag = new double[FREQS2.length];
            for (int b = 0; b < FREQS2.length; b++) {
                double coeff = 2.0 * Math.cos(2.0 * Math.PI * FREQS2[b] / RATE), s1 = 0, s2 = 0;
                for (int i = 0; i < len; i++) { double s0 = samples[from + i] * win[i] + coeff * s1 - s2; s2 = s1; s1 = s0; }
                mag[b] = Math.sqrt(Math.max(0, s1 * s1 + s2 * s2 - coeff * s1 * s2));
                total += mag[b];
            }
            if (total > 0) for (int b = 0; b < mag.length; b++) out[sl * 12 + b] = Math.sqrt(mag[b] / total);
        }
        double mx = Math.max(rms[0], Math.max(rms[1], rms[2]));
        if (mx > 0) for (int sl = 0; sl < 3; sl++) out[39 + sl] = rms[sl] / mx;
        return out;
    }

    static double similarityV2(double[] a, double[] b) {
        if (a == null || b == null || a.length != V2_LEN || b.length != V2_LEN) return 0;
        double dot = 0, aa = 0, bb = 0;
        for (int i = 0; i < 36; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        double spec = aa <= 0 || bb <= 0 ? 0 : dot / Math.sqrt(aa * bb);
        double z = 0, e = 0;
        for (int i = 0; i < 3; i++) {
            z += Math.max(0, 1.0 - Math.abs(a[36 + i] - b[36 + i]) / 0.2) / 3.0;
            e += (1.0 - Math.abs(a[39 + i] - b[39 + i])) / 3.0;
        }
        return 0.55 * spec + 0.15 * z + 0.30 * e;
    }

    static double minPairwiseV2(double[][] takes) {
        double min = 1;
        for (int i = 0; i < takes.length; i++)
            for (int j = i + 1; j < takes.length; j++) min = Math.min(min, similarityV2(takes[i], takes[j]));
        return min;
    }

    static String encodeV2(double[] f) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < f.length; i++) { if (i > 0) b.append(','); b.append(String.format(java.util.Locale.US, "%.5f", f[i])); }
        return b.toString();
    }

    static double[] decodeV2(String s) {
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length != V2_LEN) return null;
            double[] f = new double[V2_LEN];
            for (int i = 0; i < V2_LEN; i++) f[i] = Double.parseDouble(p[i]);
            return f;
        } catch (Exception e) { return null; }
    }

    /** Best V2 score across stored takes (separated by '|'). */
    static double maxSimilarityV2(double[] sample, String encodedTakes) {
        if (encodedTakes == null || encodedTakes.isEmpty()) return 0;
        double best = 0;
        for (String t : encodedTakes.split("\\|")) best = Math.max(best, similarityV2(sample, decodeV2(t)));
        return best;
    }
}
