package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** On-device clap / enrolled-sound listener. Raw microphone audio is never persisted. */
public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static final String ACTION_SOUND_EVENT = "com.snapscroll.SOUND_EVENT";
    public static final String EXTRA_EVENT_MESSAGE = "event_message";
    public static volatile boolean isRunning = false;
    public static volatile String lastError = null;
    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private static final int RATE = 16000; // must match SoundDetector / AudioFeatures
    private AudioRecord recorder;
    private Thread worker;
    private volatile boolean keepRunning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastAcceptedEventNs = 0;
    private long pendingSingleNs = 0;
    private String pendingAction, pendingPackage, pendingDoubleAction, pendingDoublePackage;
    private Runnable pendingSingleRunnable;
    // Debounce only duplicate fragments of one impact; allow normal fast double claps.
    private static final long MIN_EVENT_GAP_NS = 65_000_000L;

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopMonitoring(); stopSelf(); return START_NOT_STICKY; }
        if (!isRunning) startMonitoring();
        return isRunning ? START_STICKY : START_NOT_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Intent stop = new Intent(this, SoundMonitorService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return b.setSmallIcon(R.drawable.ic_mic).setContentTitle("SnapScroll is active")
                .setContentText("Listening for your sound or clap · on-device").setContentIntent(pi).setOngoing(true)
                .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_mic), "Pause", stopPi).build()).build();
    }
    private void startMonitoring() {
        try {
            lastError = null;
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(NOTIFICATION_ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(NOTIFICATION_ID, notification());
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android reports no usable microphone buffer: " + min);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE * 2));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Microphone could not be initialised");
            // Keep the microphone signal unprocessed. AGC can amplify tiny tongue/lip clicks
            // until they cross the trigger threshold; device DSP also varies by manufacturer.
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Microphone did not start recording");
            keepRunning = true; isRunning = true;
            worker = new Thread(this::readLoop, "SnapScroll-Audio"); worker.start();
        } catch (Exception e) {
            keepRunning = false; isRunning = false;
            lastError = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            releaseRecorder(); stopForeground(true); stopSelf();
            android.util.Log.e("SnapScroll", "Unable to start microphone", e);
        }
    }

    private void readLoop() {
        short[] frame = new short[SoundDetector.FRAME];
        SoundDetector detector = new SoundDetector();
        AudioRecord active = recorder;
        while (keepRunning && active != null) {
            int n = active.read(frame, 0, frame.length);
            if (!keepRunning) break; // deliberate stop releases the recorder under us; not an error
            if (n < 0) {
                final int err = n;
                handler.post(() -> { lastError = "Microphone read failed (" + err + ")"; isRunning = false; stopSelf(); });
                break;
            }
            SoundDetector.Event e = detector.feed(frame, n);
            if (e == null) continue;
            long now = SystemClock.elapsedRealtimeNanos();
            if (now - lastAcceptedEventNs >= MIN_EVENT_GAP_NS) {
                lastAcceptedEventNs = now;
                handler.post(() -> classifyAndDispatch(e, now));
            }
        }
    }

    private void classifyAndDispatch(SoundDetector.Event ev, long eventNs) {
        double[] features = ev.features;
        int durationFrames = ev.durationFrames;
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        if (!p.getBoolean("sound_enabled", true)) return;
        boolean clapOn = p.getBoolean("clap_on", true);
        boolean customOn = p.getBoolean("custom_on", false) && p.getString("custom_feature", null) != null;
        double clapScore = AudioFeatures.clapScore(features);

        // "Your sound": v2 temporal fingerprint with a threshold derived from the user's own
        // three takes and a duration gate. Older enrollments fall back to the v1 matcher.
        String v2 = p.getString("custom_v2", null);
        boolean useV2 = v2 != null && !v2.isEmpty();
        double customScore, customThr;
        boolean customDurationOk;
        if (useV2) {
            customScore = AudioFeatures.maxSimilarityV2(ev.featuresV2, v2);
            customThr = p.getFloat("custom_thr", 0.88f);
            int dmin = p.getInt("custom_dmin", 2), dmax = p.getInt("custom_dmax", 60);
            customDurationOk = durationFrames >= Math.floor(dmin * 0.6) - 1 && durationFrames <= Math.ceil(dmax * 1.6) + 1;
        } else {
            double[] template = AudioFeatures.decode(p.getString("custom_feature", null));
            customScore = AudioFeatures.maxSimilarity(features, p.getString("custom_features", null), template);
            customThr = 0.83;
            customDurationOk = durationFrames >= 2 && durationFrames <= 60;
        }
        boolean customMatch = customOn && customDurationOk && customScore >= customThr;
        if (customOn && !customMatch && customScore >= customThr - 0.12)
            broadcastEvent(String.format(java.util.Locale.US, "Heard a similar sound · %d%% match, needs %d%%",
                    Math.round(customScore * 100), Math.round(customThr * 100)));

        // Two trigger profiles only. Clap uses event duration plus broadband spectral evidence.
        boolean[] match = new boolean[] {
                customMatch,
                clapOn && durationFrames >= 2 && durationFrames <= 40 && clapScore >= 0.60
        };
        double[] scores = new double[] { customScore, clapScore };
        int best = -1;
        double bestScore = 0, secondScore = 0;
        for (int i = 0; i < match.length; i++) {
            if (!match[i]) continue;
            if (scores[i] > bestScore) { secondScore = bestScore; bestScore = scores[i]; best = i; }
            else if (scores[i] > secondScore) secondScore = scores[i];
        }
        // If two trigger profiles claim the same event with nearly equal confidence,
        // ignore it rather than firing an unintended action.
        if (best < 0 || (secondScore > 0 && bestScore - secondScore < 0.07)) return;
        String id = new String[] { "custom", "clap" }[best];
        broadcastEvent(best == 0 ? String.format(java.util.Locale.US, "Your sound detected · %d%% match", Math.round(customScore * 100)) : "Clap detected");
        String defaultAction = new String[] { "down", "up" }[best];
        String action = p.getString(id + "_act", defaultAction);
        String doubleAction = p.getString(id + "_double_act", new String[] { "up", "down" }[best]);
        String pkg = p.getString(id + "_pkg", null);
        dispatchTimed(action, pkg, doubleAction, pkg, eventNs, p.getInt("double_delay_ms", 1000));
    }

    private void dispatchTimed(String action, String pkg, String doubleAction, String doublePkg, long nowNs, int windowMs) {
        long windowNs = Math.max(0, Math.min(2000, windowMs)) * 1_000_000L;
        if (windowNs == 0) {
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null; pendingSingleNs = 0;
            broadcastEvent("Single sound recognized");
            ScrollAccessibilityService.perform(this, action, pkg);
            buzz(false);
            return;
        }
        if (pendingSingleNs != 0) {
            long gapMs = (nowNs - pendingSingleNs) / 1_000_000L;
            if (gapMs <= windowNs / 1_000_000L) {
                pendingSingleNs = 0;
                if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
                pendingSingleRunnable = null;
                getSharedPreferences("snapscroll", MODE_PRIVATE).edit().putInt("last_gap_ms", (int) gapMs).apply();
                broadcastEvent("Double sound recognized · " + gapMs + " ms apart");
                ScrollAccessibilityService.perform(this, pendingDoubleAction, pendingDoublePackage);
                pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null;
                buzz(true);
                return;
            }
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            broadcastEvent("Single sound recognized");
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
            pendingSingleNs = 0; pendingAction = null; pendingPackage = null;
        }
        broadcastEvent("First sound detected · waiting for second");
        pendingSingleNs = nowNs; pendingAction = action; pendingPackage = pkg;
        pendingDoubleAction = doubleAction; pendingDoublePackage = doublePkg;
        final long token = nowNs;
        Runnable single = () -> {
            if (pendingSingleNs == token) {
                pendingSingleNs = 0;
                broadcastEvent("Single sound recognized");
                ScrollAccessibilityService.perform(this, action, pkg);
                pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null; pendingSingleRunnable = null;
            }
        };
        pendingSingleRunnable = single;
        handler.postDelayed(single, windowMs);
        buzz(false);
    }

    private void broadcastEvent(String message) {
        Intent event = new Intent(ACTION_SOUND_EVENT);
        event.setPackage(getPackageName());
        event.putExtra(EXTRA_EVENT_MESSAGE, message);
        sendBroadcast(event);
    }

    private void buzz(boolean doubled) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            long[] pattern = doubled ? new long[]{0, 55, 65, 55} : new long[]{0, 28};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        } catch (Exception ignored) { }
    }

    private void clearPending() {
        if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
        pendingSingleRunnable = null; pendingSingleNs = 0;
        pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null;
    }

    private void releaseRecorder() {
        if (recorder != null) { try { recorder.stop(); } catch (Exception ignored) { } try { recorder.release(); } catch (Exception ignored) { } recorder = null; }
    }
    private void stopMonitoring() {
        keepRunning = false; isRunning = false;
        // Flush a waiting first sound so pausing never silently swallows it.
        if (pendingSingleNs != 0 && pendingAction != null) ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
        clearPending();
        releaseRecorder();
        if (worker != null) { worker.interrupt(); worker = null; }
        stopForeground(true);
    }
    @Override public void onDestroy() { stopMonitoring(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
