package com.snapscroll.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 10, REQ_NOTIF = 11, REQ_IMPORT = 12;
    private SpeechRecognizer voiceRecognizer;
    private SharedPreferences prefs;
    private TextView status, serviceStatus, testStatus;
    private boolean testMode = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("snapscroll", MODE_PRIVATE);
        testMode = prefs.getBoolean("test_mode", false);
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(2), dp(5), dp(2), dp(5)); return t;
    }
    private Button button(String s, Runnable action) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setOnClickListener(v -> action.run());
        return b;
    }
    private void buildUi() {
        int bg = 0xFF080A0D, fg = 0xFFF1F3F5, muted = 0xFF9AA3AD, accent = 0xFFB7F36B;
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("SNAPSCROLL", 13, accent); brand.setLetterSpacing(.18f); root.addView(brand);
        TextView heading = text("Sound in.\nScroll on.", 34, fg); heading.setTypeface(null, 1); heading.setPadding(0, dp(10), 0, dp(4)); root.addView(heading);
        root.addView(text("A quiet, on-device sound controller", 14, muted));

        LinearLayout panel = panel(root, "LISTENING STATUS");
        status = text("●  Paused", 20, fg); panel.addView(status);
        serviceStatus = text("Microphone service is not running", 13, muted); panel.addView(serviceStatus);
        panel.addView(button("Start listening", this::startListening));
        panel.addView(button("Pause listening", this::stopListening));

        LinearLayout profiles = panel(root, "SOUND PROFILES");
        profiles.addView(text("Built-in profiles", 16, fg));
        profiles.addView(text("Finger snap  ·  Finger pop  ·  Hand clap", 14, muted));
        profiles.addView(button("Configure single / double actions", () -> showMappings()));
        profiles.addView(button("Import a custom sound sample", () -> importSample()));

        LinearLayout test = panel(root, "TEST SOUND MODE");
        Switch testSwitch = new Switch(this); testSwitch.setText("Test only — never scroll or lock"); testSwitch.setTextColor(fg); testSwitch.setChecked(testMode);
        testSwitch.setOnCheckedChangeListener((v, checked) -> { testMode = checked; prefs.edit().putBoolean("test_mode", checked).apply(); updateStatus(); });
        test.addView(testSwitch);
        testStatus = text("Test results will appear here while listening.", 13, muted); test.addView(testStatus);
        test.addView(button("Clear test result", () -> { prefs.edit().remove("last_test").apply(); testStatus.setText("Test results cleared."); }));

        LinearLayout controls = panel(root, "DEVICE CONTROLS");
        Switch lock = new Switch(this); lock.setText("Allow voice command to lock screen"); lock.setTextColor(fg);
        lock.setChecked(prefs.getBoolean("lock_enabled", false));
        lock.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean("lock_enabled", checked).apply()); controls.addView(lock);
        controls.addView(text("Screen locking is optional and currently available by on-demand voice command only. Sound-triggered locking is withheld until clap recognition is reliable.", 13, muted));

        LinearLayout settings = panel(root, "SETUP & PERMISSIONS");
        settings.addView(button("Grant microphone permission", this::requestAudio));
        settings.addView(button("Enable SnapScroll accessibility", () -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        settings.addView(button("Notification settings", () -> { if (Build.VERSION.SDK_INT >= 26) startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName())); }));
        settings.addView(button("Voice command (on demand)", this::voiceCommand));
        settings.addView(text("Offline processing · No account · No cloud · No ads", 12, muted));
        updateStatus();
    }

    private LinearLayout panel(LinearLayout root, String title) {
        LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(16), dp(12), dp(16), dp(12));
        p.setBackgroundColor(0xFF151A20); LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(18); root.addView(p, lp);
        TextView t = text(title, 11, 0xFFB7F36B); t.setLetterSpacing(.12f); p.addView(t); return p;
    }
    private void updateStatus() {
        if (status == null) return;
        boolean running = SoundMonitorService.isRunning;
        status.setText(running ? "●  Listening" : "●  Paused"); status.setTextColor(running ? 0xFFB7F36B : 0xFFF1F3F5);
        serviceStatus.setText(running ? (testMode ? "Test mode active — actions suppressed" : "Listening locally in the background") : "Microphone service is not running");
        if (testStatus != null) testStatus.setText(prefs.getString("last_test", "Test results will appear here while listening."));
    }
    private void requestAudio() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        else Toast.makeText(this, "Microphone permission is already granted", Toast.LENGTH_SHORT).show();
    }
    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF); return;
        }
        Intent i = new Intent(this, SoundMonitorService.class); i.setAction(SoundMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.postDelayed(this::updateStatus, 500);
    }
    private void stopListening() {
        Intent i = new Intent(this, SoundMonitorService.class); i.setAction(SoundMonitorService.ACTION_STOP); startService(i); updateStatus();
    }
    private void showMappings() {
        String[] options = {"Single sound → Scroll down", "Double sound → Scroll up", "Enable voice lock command", "Reset defaults"};
        new android.app.AlertDialog.Builder(this).setTitle("Action mapping") .setItems(options, (d, which) -> {
            if (which == 0) prefs.edit().putString("single_action", "down").apply();
            if (which == 1) prefs.edit().putString("double_action", "up").apply();
            if (which == 2) { prefs.edit().putBoolean("lock_enabled", true).apply(); }
            if (which == 3) prefs.edit().clear().apply();
            Toast.makeText(this, "Preference saved", Toast.LENGTH_SHORT).show();
        }).show();
    }
    private void importSample() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("audio/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_IMPORT);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_IMPORT && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            prefs.edit().putString("custom_sample_uri", uri.toString()).apply();
            Toast.makeText(this, "Sample imported. It is stored for future profile matching; import alone does not train a classifier.", Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }
    private void voiceCommand() {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            Toast.makeText(this, "On-device voice recognition is not available on this device. SnapScroll will not use an online fallback.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        try {
            if (voiceRecognizer != null) voiceRecognizer.destroy();
            voiceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            voiceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { Toast.makeText(MainActivity.this, "Listening for one command…", Toast.LENGTH_SHORT).show(); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) { Toast.makeText(MainActivity.this, "Voice recognition ended (code " + error + ")", Toast.LENGTH_SHORT).show(); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) runVoiceAction(matches.get(0));
                    voiceRecognizer.destroy(); voiceRecognizer = null;
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say scroll down, scroll up, or lock screen");
            voiceRecognizer.startListening(intent);
        } catch (Exception e) {
            if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
            Toast.makeText(this, "On-device voice recognition could not start", Toast.LENGTH_LONG).show();
        }
    }
    private void runVoiceAction(String phrase) {
        String spoken = phrase.toLowerCase(Locale.ROOT);
        if (spoken.contains("scroll down")) ScrollAccessibilityService.performScroll(this, false);
        else if (spoken.contains("scroll up")) ScrollAccessibilityService.performScroll(this, true);
        else if (spoken.contains("lock screen") || spoken.contains("lock phone")) {
            if (prefs.getBoolean("lock_enabled", false)) ScrollAccessibilityService.performLock(this);
            else Toast.makeText(this, "Enable the optional voice lock command in Device Controls first", Toast.LENGTH_LONG).show();
        } else Toast.makeText(this, "Command not recognised: " + phrase, Toast.LENGTH_SHORT).show();
    }
    @Override protected void onResume() { super.onResume(); updateStatus(); }
    @Override protected void onDestroy() { if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; } super.onDestroy(); }
}
