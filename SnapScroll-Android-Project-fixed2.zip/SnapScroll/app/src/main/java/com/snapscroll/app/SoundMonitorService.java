package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;

public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static volatile boolean isRunning = false;
    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private AudioRecord recorder;
    private Thread worker;
    private volatile boolean keepRunning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastEventAt = 0;
    private long pendingSingleAt = 0;
    private int pendingSingleLabel = 0;
    private static final long DOUBLE_WINDOW_MS = 420;
    private static final long EVENT_GUARD_MS = 180;

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopMonitoring(); stopSelf(); return START_NOT_STICKY; }
        if (!isRunning) startMonitoring();
        return START_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SnapScroll is active")
                .setContentText("Listening on-device · Tap to open controls").setContentIntent(pi).setOngoing(true).build();
    }
    private void startMonitoring() {
        try {
            startForeground(NOTIFICATION_ID, notification());
            int rate = 16000;
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Audio input is unavailable");
            recorder = new AudioRecord(MediaRecorder.AudioSource.UNPROCESSED, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                try { recorder.release(); } catch (Exception ignored) {}
                recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate));
            }
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Microphone could not be initialised");
            keepRunning = true; isRunning = true; recorder.startRecording();
            worker = new Thread(this::readLoop, "SnapScroll-Audio"); worker.start();
        } catch (Exception e) {
            isRunning = false; stopForeground(true); stopSelf();
            android.util.Log.e("SnapScroll", "Unable to start microphone", e);
        }
    }
    private void readLoop() {
        short[] data = new short[320]; // 20 ms at 16 kHz
        double noiseFloor = 170.0;
        while (keepRunning && recorder != null) {
            int n = recorder.read(data, 0, data.length);
            if (n <= 0) continue;
            double sum = 0; int peak = 0; int crossings = 0; short prev = data[0];
            for (int i = 0; i < n; i++) {
                int v = data[i]; sum += (double)v * v; peak = Math.max(peak, Math.abs(v));
                if ((v >= 0 && prev < 0) || (v < 0 && prev >= 0)) crossings++;
                prev = data[i];
            }
            double rms = Math.sqrt(sum / n);
            if (rms < noiseFloor * 2.2) noiseFloor = noiseFloor * .985 + Math.max(35, rms) * .015;
            double threshold = Math.max(900, noiseFloor * 5.0);
            long now = System.currentTimeMillis();
            if (rms > threshold && peak > 2800 && now - lastEventAt > EVENT_GUARD_MS) {
                lastEventAt = now;
                // Lightweight transient gate only. It does not reliably distinguish a snap, pop or clap.
                final int eventKind = crossings > 45 ? 1 : 0;
                final double eventRms = rms;
                final int eventPeak = peak;
                handler.post(() -> onSoundEvent(eventKind, eventRms, eventPeak));
            }
        }
    }
    private void onSoundEvent(int roughKind, double rms, int peak) {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        boolean test = p.getBoolean("test_mode", false);
        String label = roughKind == 1 ? "Sharp / bright transient" : "Sound transient";
        if (test) {
            String msg = "Detected: " + label + "\nAction executed: No (Test Mode)";
            p.edit().putString("last_test", msg).apply();
            vibrate(35);
            return;
        }
        long now = System.currentTimeMillis();
        if (pendingSingleAt != 0 && now - pendingSingleAt <= DOUBLE_WINDOW_MS) {
            pendingSingleAt = 0;
            // Double sound defaults to scroll up. No device lock is triggered by an unverified sound class.
            String action = p.getString("double_action", "up");
            if ("up".equals(action)) ScrollAccessibilityService.performScroll(this, true);
            else if ("down".equals(action)) ScrollAccessibilityService.performScroll(this, false);
            vibrate(65);
        } else {
            pendingSingleAt = now; pendingSingleLabel = roughKind;
            handler.postDelayed(() -> {
                if (pendingSingleAt == now) {
                    pendingSingleAt = 0;
                    if (p.getBoolean("test_mode", false)) {
                        p.edit().putString("last_test", "Detected: " + (pendingSingleLabel == 1 ? "Sharp / bright transient" : "Sound transient") + "\nAction executed: No (Test Mode)").apply();
                        return;
                    }
                    String action = p.getString("single_action", "down");
                    if ("up".equals(action)) ScrollAccessibilityService.performScroll(this, true);
                    else if ("down".equals(action)) ScrollAccessibilityService.performScroll(this, false);
                    vibrate(35);
                }
            }, DOUBLE_WINDOW_MS);
        }
    }
    private void vibrate(long ms) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            }
        } catch (Exception ignored) {}
    }
    private void stopMonitoring() {
        keepRunning = false; isRunning = false;
        if (recorder != null) { try { recorder.stop(); } catch (Exception ignored) {} try { recorder.release(); } catch (Exception ignored) {} recorder = null; }
        if (worker != null) { worker.interrupt(); worker = null; }
        stopForeground(true);
    }
    @Override public void onDestroy() { stopMonitoring(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
