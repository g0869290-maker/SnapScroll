import java.net.URI
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest

plugins { id("com.android.application") }

val yamnetAssetsDir = layout.buildDirectory.dir("generated/yamnetAssets")
val yamnetModelSha256 = "4d8b4a53282dc83ef04e3e7dbc4fbc98082e34e44ed798e16c3a0cdd4c584faf"
val yamnetModelUrl = "https://huggingface.co/litert-community/MediaPipe-AudioClassifier-YAMNet/resolve/main/yamnet.tflite"

fun java.io.File.sha256Hex(): String {
    val digest = MessageDigest.getInstance("SHA-256")
    inputStream().use { input ->
        val buffer = ByteArray(8192)
        while (true) {
            val read = input.read(buffer)
            if (read <= 0) break
            digest.update(buffer, 0, read)
        }
    }
    return digest.digest().joinToString("") { "%02x".format(it) }
}

android {
    namespace = "com.snapscroll.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.snapscroll.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "1.5.3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    sourceSets.getByName("main").assets.srcDir(yamnetAssetsDir)
}

dependencies {
    implementation("com.google.mediapipe:tasks-audio:1.2.3")
}

tasks.register("downloadYamnetModel") {
    val modelFile = yamnetAssetsDir.map { it.file("yamnet.tflite") }
    outputs.file(modelFile)
    outputs.upToDateWhen { false } // Always verify the pinned checksum before packaging.
    doLast {
        val destination = modelFile.get().asFile
        if (destination.exists() && destination.length() > 0L && destination.sha256Hex() == yamnetModelSha256) {
            logger.lifecycle("Verified cached YAMNet model: ${destination.length()} bytes")
        } else {
            destination.parentFile.mkdirs()
            val temporary = java.io.File(destination.parentFile, "yamnet.tflite.download")
            try {
                val connection = URI(yamnetModelUrl).toURL().openConnection() as java.net.HttpURLConnection
                connection.connectTimeout = 30_000
                connection.readTimeout = 120_000
                connection.inputStream.use { input ->
                    Files.copy(input, temporary.toPath(), StandardCopyOption.REPLACE_EXISTING)
                }
                val actual = temporary.sha256Hex()
                if (actual != yamnetModelSha256) {
                    throw GradleException("YAMNet model checksum mismatch. Expected $yamnetModelSha256 but got $actual")
                }
                Files.move(temporary.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING)
                logger.lifecycle("Downloaded and verified YAMNet model: ${destination.length()} bytes")
            } finally {
                temporary.delete()
            }
        }
    }
}

tasks.named("preBuild").configure {
    dependsOn("downloadYamnetModel")
}

tasks.matching { it.name.startsWith("merge") && it.name.endsWith("Assets") }.configureEach {
    dependsOn("downloadYamnetModel")
}
