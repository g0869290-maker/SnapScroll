# SnapScroll 1.4 (two-trigger compact build)

SnapScroll keeps the compact interface and actions from version 1.4, with exactly two sound triggers: **Your sound** and **Clap**. Whistle has been removed from the interface and listener. Audio processing is local to the phone; raw microphone audio is not saved or uploaded.

## Retained controls
- Independent enable switches for Your sound and Clap
- Separate one-sound and two-sound actions for each trigger
- Scroll down, Scroll up, Go back, Open app, Lock screen and Wake screen actions
- Configurable 0–2,000 ms double-sound window (0 means single-only)
- Accessibility service for cross-app gestures and lock-screen action
- Three-take enrollment for Your sound; record again after installing this build

## Recognition changes
- The previous overly restrictive clap duration gate has been widened so ordinary hand claps are not rejected merely for being shorter than 70 ms.
- Clap recognition combines broadband spectral spread, spectral centroid, and zero-crossing features.
- Your sound uses a more tolerant fingerprint similarity threshold and a wider event-duration range.
- No large AI model or external runtime is included; this keeps the project small (the ZIP is intended to remain around the original ~50 KB source-archive size).

## Important limits
This is lightweight signal processing, not a trained sound classifier. A clap and a similar sharp impact can sound alike to one phone microphone. A more tolerant threshold improves missed-clap behavior but can also increase false activations. Your Sound is a compact spectral fingerprint, not a personalized neural network. Test on the target phone and adjust if necessary. Very quiet sounds may be missed when they are close to the room noise floor.

## Build
Open the project in Android Studio or run the included GitHub Actions workflow. Enable microphone permission and SnapScroll's Accessibility Service on the phone. The source archive has not been compiled or physically tested in this environment.
