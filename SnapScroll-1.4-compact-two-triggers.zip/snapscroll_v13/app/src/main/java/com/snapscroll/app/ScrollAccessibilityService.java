package com.snapscroll.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class ScrollAccessibilityService extends AccessibilityService {
    private static volatile ScrollAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    private static boolean dispatchSwipe(Context context, boolean up, boolean reportResult) {
        ScrollAccessibilityService service = instance;
        if (service == null) {
            Toast.makeText(context, "SnapScroll Accessibility service is not connected. Enable it in Android settings.", Toast.LENGTH_LONG).show();
            return false;
        }
        float x = service.getResources().getDisplayMetrics().widthPixels * .5f;
        float screenHeight = service.getResources().getDisplayMetrics().heightPixels;
        // A longer, larger swipe is more likely to be recognised as a scroll by apps.
        float startY = screenHeight * (up ? .30f : .80f);
        float endY = screenHeight * (up ? .80f : .30f);
        Path path = new Path();
        path.moveTo(x, startY);
        path.lineTo(x, endY);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 360))
                .build();
        GestureResultCallback callback = reportResult ? new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription description) {
                Toast.makeText(service, "Swipe gesture delivered", Toast.LENGTH_SHORT).show();
            }
            @Override public void onCancelled(GestureDescription description) {
                Toast.makeText(service, "Android cancelled the swipe gesture", Toast.LENGTH_LONG).show();
            }
        } : null;
        boolean accepted = service.dispatchGesture(gesture, callback, null);
        if (!accepted && reportResult) {
            Toast.makeText(context, "Android did not accept the swipe gesture", Toast.LENGTH_LONG).show();
        }
        return accepted;
    }

    public static void performScroll(Context context, boolean up) {
        dispatchSwipe(context, up, false);
    }

    public static String reverse(String action) {
        if ("down".equals(action)) return "up";
        if ("up".equals(action)) return "down";
        return action;
    }

    /** Runs a configured action, including screen lock and wake (secure unlock is never bypassed). */
    public static void perform(Context context, String action, String pkg) {
        performInternal(context, action, pkg, false);
    }

    /** Directly executes a configured action and reports whether Android accepted it. */
    public static void testAction(Context context, String action, String pkg) {
        performInternal(context, action, pkg, true);
    }

    private static boolean performInternal(Context context, String action, String pkg, boolean report) {
        if ("down".equals(action)) return dispatchSwipe(context, false, report);
        if ("up".equals(action)) return dispatchSwipe(context, true, report);
        if ("back".equals(action)) {
            ScrollAccessibilityService service = instance;
            if (service == null) {
                Toast.makeText(context, "SnapScroll Accessibility service is not connected", Toast.LENGTH_LONG).show();
                return false;
            }
            boolean ok = service.performGlobalAction(GLOBAL_ACTION_BACK);
            if (report) Toast.makeText(context, ok ? "Back action sent" : "Android rejected the Back action", Toast.LENGTH_SHORT).show();
            return ok;
        }
        if ("lock".equals(action)) {
            ScrollAccessibilityService service = instance;
            if (service == null) {
                if (report) Toast.makeText(context, "Enable SnapScroll Accessibility first", Toast.LENGTH_LONG).show();
                return false;
            }
            boolean ok = Build.VERSION.SDK_INT >= 28 && service.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
            if (report) Toast.makeText(context, ok ? "Screen lock requested" : "Android could not lock the screen", Toast.LENGTH_SHORT).show();
            return ok;
        }
        if ("wake".equals(action)) {
            try {
                android.os.PowerManager pm = (android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm == null) return false;
                int flags = android.os.PowerManager.SCREEN_BRIGHT_WAKE_LOCK | android.os.PowerManager.ACQUIRE_CAUSES_WAKEUP;
                android.os.PowerManager.WakeLock wl = pm.newWakeLock(flags, "SnapScroll:WakeScreen");
                wl.acquire(2500);
                if (report) Toast.makeText(context, "Screen wake requested. Device security remains enabled.", Toast.LENGTH_SHORT).show();
                return true;
            } catch (Exception e) {
                if (report) Toast.makeText(context, "Could not wake the screen: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }
        if ("open".equals(action)) {
            if (pkg == null) {
                Toast.makeText(context, "Choose an app to open first", Toast.LENGTH_SHORT).show();
                return false;
            }
            android.content.Intent intent = context.getPackageManager().getLaunchIntentForPackage(pkg);
            if (intent == null) {
                Toast.makeText(context, "That app is no longer available", Toast.LENGTH_SHORT).show();
                return false;
            }
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(intent);
                if (report) Toast.makeText(context, "App launch requested", Toast.LENGTH_SHORT).show();
                return true;
            } catch (Exception e) {
                if (report) Toast.makeText(context, "Could not open that app: " + e.getMessage(), Toast.LENGTH_LONG).show();
                return false;
            }
        }
        return false;
    }

    public static void performLock(Context context) {
        ScrollAccessibilityService s = instance;
        if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 28) s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }
}
