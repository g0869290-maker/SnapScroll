package com.snapscroll.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int REQ_AUDIO = 10, REQ_NOTIF = 11, REQ_IMPORT = 12;
    private static final int BG = 0xFF000000, FG = 0xFFF7F7FA, MUTED = 0xFFA3A3AD;
    private static final int PURPLE = 0xFFA855F7, SOFT = 0xFFC084FC, ORANGE = 0xFFFF8500, GREEN = 0xFF72DDA0;
    private static final String[] NAV_LABELS = {"Home", "Controls", "Test", "Settings"};
    private static final int[] NAV_ICONS = {R.drawable.ic_nav_home, R.drawable.ic_nav_controls, R.drawable.ic_nav_test, R.drawable.ic_nav_settings};
    private static final String[] ACTION_LABELS = {"Scroll down", "Scroll up", "Do nothing"};
    private static final String[] ACTION_VALUES = {"down", "up", "none"};

    private SpeechRecognizer voiceRecognizer;
    private SharedPreferences prefs;
    private final View[] pages = new View[4];
    private final FrameLayout[] navItems = new FrameLayout[4];
    private final ImageView[] navIcons = new ImageView[4];
    private final TextView[] navLabels = new TextView[4];
    private TextView heroPill, heroTitle, heroSub, fingerSub, delayLabel, sampleStatus, singleSummary, doubleSummary, testStatus;
    private Switch fingerSwitch, lockSwitch, testSwitch;
    private SeekBar delaySeek;
    private boolean testMode = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("snapscroll", MODE_PRIVATE);
        testMode = prefs.getBoolean("test_mode", false);
        buildUi();
        selectTab(0);
    }

    @Override protected void onResume() {
        super.onResume();
        prefs.registerOnSharedPreferenceChangeListener(this);
        updateStatus();
    }

    @Override protected void onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        runOnUiThread(this::updateStatus);
    }

    // ---------- helpers ----------

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(2), dp(4), dp(2), dp(4));
        return t;
    }

    private TextView screenTitle(String s) {
        TextView t = text(s, 30, FG);
        t.setTypeface(null, 1);
        t.setPadding(dp(2), dp(4), dp(2), dp(12));
        return t;
    }

    private GradientDrawable glass(float radiusDp, int topColor, int bottomColor, int strokeColor) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{topColor, bottomColor});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private GradientDrawable cardGlass() {
        return glass(26, 0x2EFFFFFF, 0x0EFFFFFF, 0x2EFFFFFF);
    }

    private GradientDrawable pill(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private ImageView icon(int resId, int sizeDp, int tint) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(resId);
        if (tint != 0) iv.setColorFilter(tint);
        return iv;
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(22), dp(30), dp(22), dp(130));
        return c;
    }

    private View page(LinearLayout col) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(col);
        return sv;
    }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(20), dp(16), dp(20), dp(16));
        p.setBackground(cardGlass());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        parent.addView(p, lp);
        if (title != null) {
            TextView t = text(title, 11, SOFT);
            t.setLetterSpacing(.12f);
            p.addView(t);
        }
        return p;
    }

    private void styleSwitch(Switch s, String label) {
        s.setText(label);
        s.setTextColor(FG);
        s.setTextSize(15);
        int[][] states = {{android.R.attr.state_checked}, {}};
        s.setTrackTintList(new ColorStateList(states, new int[]{ORANGE, 0xFF3A3A41}));
        s.setThumbTintList(new ColorStateList(states, new int[]{0xFFFFFFFF, 0xFFD0D0D6}));
        s.setPadding(0, dp(8), 0, dp(8));
    }

    private TextView makeButton(String label, GradientDrawable bg, int color, Runnable action) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(color);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        b.setBackground(bg);
        b.setClickable(true);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView glassButton(String label, Runnable action) {
        return makeButton(label, glass(16, 0x26FFFFFF, 0x14FFFFFF, 0x33FFFFFF), FG, action);
    }

    private TextView primaryButton(String label, Runnable action) {
        return makeButton(label, pill(PURPLE, 16), 0xFFFFFFFF, action);
    }

    private TextView smallButton(String label, Runnable action) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(FG);
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(glass(99, 0x26FFFFFF, 0x14FFFFFF, 0x33FFFFFF));
        b.setClickable(true);
        b.setOnClickListener(v -> action.run());
        return b;
    }

    /** A "Your Sounds" row: icon, title + subtitle, trailing view, optional chevron. */
    private LinearLayout soundRow(int iconRes, String title, TextView subtitle, View trailing, boolean chevron, Runnable onTap) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(14), dp(4), dp(14));
        r.addView(icon(iconRes, 40, 0), new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(12), 0, dp(8), 0);
        TextView t = text(title, 17, FG);
        t.setTypeface(null, 1);
        t.setPadding(0, 0, 0, 0);
        info.addView(t);
        if (subtitle != null) {
            subtitle.setTextSize(13);
            subtitle.setTextColor(MUTED);
            subtitle.setPadding(0, dp(2), 0, 0);
            info.addView(subtitle);
        }
        r.addView(info, new LinearLayout.LayoutParams(0, -2, 1f));
        if (trailing != null) {
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-2, -2);
            r.addView(trailing, tp);
        }
        if (chevron) {
            r.addView(icon(R.drawable.ic_chevron, 20, MUTED), new LinearLayout.LayoutParams(dp(20), dp(20)));
        }
        if (onTap != null) {
            r.setClickable(true);
            r.setOnClickListener(v -> onTap.run());
        }
        return r;
    }

    private View divider() {
        View d = new View(this);
        d.setBackgroundColor(0x14FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        d.setLayoutParams(lp);
        return d;
    }

    /** Orange toggle used as the trailing control on sound rows. */
    private Switch soundToggle() {
        Switch s = new Switch(this);
        styleSwitch(s, "");
        s.setPadding(0, 0, 0, 0);
        return s;
    }

    // ---------- layout ----------

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        pages[0] = page(homePage());
        pages[1] = page(controlsPage());
        pages[2] = page(testPage());
        pages[3] = page(settingsPage());
        for (View v : pages) frame.addView(v, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams navParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        navParams.setMargins(dp(16), 0, dp(16), dp(18));
        frame.addView(navBar(), navParams);
        setContentView(frame);
        updateStatus();
    }

    private LinearLayout header() {
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.HORIZONTAL);
        h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(0, 0, 0, dp(24));
        h.addView(icon(R.drawable.ic_snap_hand, 46, 0), new LinearLayout.LayoutParams(dp(46), dp(46)));
        LinearLayout name = new LinearLayout(this);
        name.setOrientation(LinearLayout.HORIZONTAL);
        name.setPadding(dp(10), 0, 0, 0);
        TextView snap = text("Snap", 24, FG);
        snap.setTypeface(null, 1);
        TextView scroll = text("Scroll", 24, SOFT);
        scroll.setTypeface(null, 1);
        scroll.post(() -> {
            LinearGradient lg = new LinearGradient(0, 0, scroll.getWidth(), 0,
                    0xFFE9D5FF, 0xFFA855F7, Shader.TileMode.CLAMP);
            scroll.getPaint().setShader(lg);
            scroll.invalidate();
        });
        name.addView(snap);
        name.addView(scroll);
        h.addView(name, new LinearLayout.LayoutParams(0, -2, 1f));
        ImageView gear = icon(R.drawable.ic_gear, 28, FG);
        gear.setClickable(true);
        gear.setPadding(dp(6), dp(6), dp(6), dp(6));
        gear.setOnClickListener(v -> selectTab(3));
        h.addView(gear, new LinearLayout.LayoutParams(dp(42), dp(42)));
        return h;
    }

    private LinearLayout homePage() {
        LinearLayout c = column();
        c.addView(header());

        // Hero card
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        heroPill = text("", 14, SOFT);
        heroPill.setBackground(pill(0x33A855F7, 99));
        heroPill.setPadding(dp(14), dp(7), dp(14), dp(7));
        left.addView(heroPill);
        heroTitle = text("", 34, FG);
        heroTitle.setTypeface(null, 1);
        heroTitle.setPadding(dp(2), dp(10), dp(2), 0);
        left.addView(heroTitle);
        heroSub = text("", 14, MUTED);
        left.addView(heroSub);
        hero.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));

        // Glowing ring button: outer halo + inner purple ring with hand
        FrameLayout halo = new FrameLayout(this);
        GradientDrawable haloBg = new GradientDrawable();
        haloBg.setShape(GradientDrawable.OVAL);
        haloBg.setColor(0x26A855F7);
        halo.setBackground(haloBg);
        FrameLayout ring = new FrameLayout(this);
        GradientDrawable ringBg = new GradientDrawable();
        ringBg.setShape(GradientDrawable.OVAL);
        ringBg.setColor(0xFF0B0A0F);
        ringBg.setStroke(dp(3), PURPLE);
        ring.setBackground(ringBg);
        ring.addView(icon(R.drawable.ic_snap_hand, 62, 0), new FrameLayout.LayoutParams(dp(62), dp(62), Gravity.CENTER));
        ring.setClickable(true);
        ring.setOnClickListener(v -> toggleListening());
        halo.addView(ring, new FrameLayout.LayoutParams(dp(118), dp(118), Gravity.CENTER));
        hero.addView(halo, new LinearLayout.LayoutParams(dp(140), dp(140)));

        LinearLayout heroCard = new LinearLayout(this);
        heroCard.setOrientation(LinearLayout.VERTICAL);
        heroCard.setPadding(dp(20), dp(18), dp(16), dp(18));
        heroCard.setBackground(cardGlass());
        heroCard.addView(hero);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        c.addView(heroCard, hp);

        // Your Sounds
        TextView sectionTitle = text("Your Sounds", 24, FG);
        sectionTitle.setTypeface(null, 1);
        sectionTitle.setPadding(dp(2), dp(26), dp(2), dp(10));
        c.addView(sectionTitle);

        LinearLayout sounds = new LinearLayout(this);
        sounds.setOrientation(LinearLayout.VERTICAL);
        sounds.setPadding(dp(16), dp(4), dp(16), dp(6));
        sounds.setBackground(cardGlass());
        c.addView(sounds);

        // Finger Snap: toggle controls the sound trigger, tap row edits actions
        fingerSub = text("", 13, MUTED);
        fingerSwitch = soundToggle();
        fingerSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (checked != prefs.getBoolean("sound_enabled", true))
                prefs.edit().putBoolean("sound_enabled", checked).apply();
        });
        sounds.addView(soundRow(R.drawable.ic_snap_hand, "Finger Snap", fingerSub, fingerSwitch, true, this::editActions));
        sounds.addView(divider());

        // Clap and Custom Sound: visual only for now (not detected separately yet)
        TextView clapSub = text("Next Item / Previous Item", 13, MUTED);
        Switch clapSwitch = soundToggle();
        clapSwitch.setChecked(prefs.getBoolean("clap_enabled", false));
        clapSwitch.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean("clap_enabled", checked).apply());
        sounds.addView(soundRow(R.drawable.ic_clap, "Clap", clapSub, clapSwitch, true, null));
        sounds.addView(divider());

        TextView customSub = text("Open App", 13, MUTED);
        Switch customSwitch = soundToggle();
        customSwitch.setChecked(prefs.getBoolean("custom_enabled", false));
        customSwitch.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean("custom_enabled", checked).apply());
        sounds.addView(soundRow(R.drawable.ic_wave, "Custom Sound", customSub, customSwitch, true, null));
        sounds.addView(divider());

        sampleStatus = text("", 13, MUTED);
        sounds.addView(soundRow(R.drawable.ic_plus_circle, "Add Custom Sound", null, null, true, this::importSample));
        sounds.addView(divider());

        // Double Sound Delay
        LinearLayout delay = new LinearLayout(this);
        delay.setOrientation(LinearLayout.VERTICAL);
        delay.setPadding(dp(4), dp(14), dp(4), dp(14));
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.addView(icon(R.drawable.ic_clock, 40, 0), new LinearLayout.LayoutParams(dp(40), dp(40)));
        LinearLayout dinfo = new LinearLayout(this);
        dinfo.setOrientation(LinearLayout.VERTICAL);
        dinfo.setPadding(dp(12), 0, dp(8), 0);
        TextView dt = text("Double Sound Delay", 17, FG);
        dt.setTypeface(null, 1);
        dinfo.addView(dt);
        TextView dsub = text("Wait briefly for a second sound", 13, MUTED);
        dinfo.addView(dsub);
        top.addView(dinfo, new LinearLayout.LayoutParams(0, -2, 1f));
        delayLabel = text("", 15, FG);
        delayLabel.setBackground(glass(14, 0x1FFFFFFF, 0x0DFFFFFF, 0x33FFFFFF));
        delayLabel.setPadding(dp(14), dp(8), dp(14), dp(8));
        delayLabel.setClickable(true);
        delayLabel.setOnClickListener(v -> pickDelay());
        top.addView(delayLabel);
        delay.addView(top);

        delaySeek = new SeekBar(this);
        delaySeek.setMax(12);
        delaySeek.setProgressTintList(ColorStateList.valueOf(PURPLE));
        delaySeek.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF));
        delaySeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int progress, boolean fromUser) {
                if (!fromUser) return;
                prefs.edit().putInt("double_delay_ms", 200 + progress * 50).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.topMargin = dp(8);
        delay.addView(delaySeek, sp);
        sounds.addView(delay);
        return c;
    }

    private LinearLayout controlsPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Controls"));

        LinearLayout actions = card(c, "SOUND ACTIONS");
        singleSummary = text("", 15, FG);
        actions.addView(singleSummary);
        actions.addView(glassButton("Set single sound action", () -> pickAction("single_action", "Single sound")));
        doubleSummary = text("", 15, FG);
        actions.addView(doubleSummary);
        actions.addView(glassButton("Set double sound action", () -> pickAction("double_action", "Double sound")));
        actions.addView(glassButton("Swap single and double", this::swapActions));

        LinearLayout sample = card(c, "CUSTOM SAMPLE");
        sample.addView(text("Stores an audio file you choose. Importing does not train a classifier yet.", 13, MUTED));
        sample.addView(glassButton("Import a custom sound sample", this::importSample));

        LinearLayout voice = card(c, "VOICE & LOCK");
        lockSwitch = new Switch(this);
        styleSwitch(lockSwitch, "Allow voice command to lock screen");
        lockSwitch.setOnCheckedChangeListener((v, checked) -> {
            if (checked != prefs.getBoolean("lock_enabled", false))
                prefs.edit().putBoolean("lock_enabled", checked).apply();
        });
        voice.addView(lockSwitch);
        voice.addView(text("Screen locking works only through the on-demand voice command. Sound-triggered locking is off.", 13, MUTED));
        voice.addView(glassButton("Voice command (on demand)", this::voiceCommand));
        return c;
    }

    private LinearLayout testPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Test"));

        LinearLayout t = card(c, "TEST SOUND MODE");
        testSwitch = new Switch(this);
        styleSwitch(testSwitch, "Test only \u2014 never scroll or lock");
        testSwitch.setOnCheckedChangeListener((v, checked) -> {
            testMode = checked;
            if (checked != prefs.getBoolean("test_mode", false))
                prefs.edit().putBoolean("test_mode", checked).apply();
            updateStatus();
        });
        t.addView(testSwitch);
        t.addView(text("Test mode reports what would happen without scrolling or locking. Start listening first.", 13, MUTED));

        LinearLayout r = card(c, "LAST TEST RESULT");
        testStatus = text("", 14, FG);
        r.addView(testStatus);
        r.addView(glassButton("Clear test result", () -> prefs.edit().remove("last_test").apply()));
        return c;
    }

    private LinearLayout settingsPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Settings"));

        LinearLayout perms = card(c, "PERMISSIONS");
        perms.addView(glassButton("Grant microphone permission", this::requestAudio));
        perms.addView(glassButton("Notification settings", this::openNotificationSettings));
        perms.addView(glassButton("Enable SnapScroll accessibility", () ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        LinearLayout about = card(c, "PRIVACY");
        about.addView(text("Offline processing \u00b7 No account \u00b7 No cloud \u00b7 No ads", 13, MUTED));
        about.addView(text("SnapScroll uses a transient detector, not a trained snap, pop or clap classifier. Do not rely on it in noisy places or for safety.", 13, MUTED));
        return c;
    }

    private LinearLayout navBar() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(8), dp(8), dp(8));
        nav.setBackground(glass(40, 0xCC1A1A1F, 0xB30C0C10, 0x40FFFFFF));
        for (int i = 0; i < 4; i++) {
            final int index = i;
            FrameLayout item = new FrameLayout(this);
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(0, dp(10), 0, dp(10));
            ImageView iv = icon(NAV_ICONS[i], 26, MUTED);
            TextView label = text(NAV_LABELS[i], 12, MUTED);
            label.setGravity(Gravity.CENTER);
            col.addView(iv, new LinearLayout.LayoutParams(dp(26), dp(26)));
            col.addView(label);
            item.addView(col, new FrameLayout.LayoutParams(-1, -2));
            item.setClickable(true);
            item.setOnClickListener(v -> selectTab(index));
            navItems[i] = item;
            navIcons[i] = iv;
            navLabels[i] = label;
            nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return nav;
    }

    private void selectTab(int index) {
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            boolean active = i == index;
            if (active) {
                GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{0xFF6D28D9, 0xFF3B0764});
                g.setCornerRadius(dp(26));
                navItems[i].setBackground(g);
            } else {
                navItems[i].setBackground(null);
            }
            int color = active ? FG : MUTED;
            navIcons[i].setColorFilter(color);
            navLabels[i].setTextColor(color);
        }
    }

    // ---------- actions ----------

    private void toggleListening() {
        if (SoundMonitorService.isRunning) stopListening(); else startListening();
    }

    private void editActions() {
        pickAction("single_action", "Finger Snap: single sound");
    }

    private void swapActions() {
        String single = prefs.getString("single_action", "down");
        String dbl = prefs.getString("double_action", "up");
        prefs.edit().putString("single_action", dbl).putString("double_action", single).apply();
        Toast.makeText(this, "Actions swapped", Toast.LENGTH_SHORT).show();
    }

    private void pickDelay() {
        String[] items = new String[13];
        for (int i = 0; i <= 12; i++) items[i] = (200 + i * 50) + " ms";
        new AlertDialog.Builder(this).setTitle("Double sound delay").setItems(items, (d, which) ->
                prefs.edit().putInt("double_delay_ms", 200 + which * 50).apply()).show();
    }

    private String actionLabel(String value) {
        if ("down".equals(value)) return "Scroll Down";
        if ("up".equals(value)) return "Scroll Up";
        return "Do nothing";
    }

    private void pickAction(String key, String title) {
        new AlertDialog.Builder(this).setTitle(title).setItems(ACTION_LABELS, (d, which) -> {
            prefs.edit().putString(key, ACTION_VALUES[which]).apply();
            Toast.makeText(this, title + " set to " + ACTION_LABELS[which], Toast.LENGTH_SHORT).show();
        }).show();
    }

    private void openNotificationSettings() {
        if (Build.VERSION.SDK_INT >= 26) {
            startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
        }
    }

    private void updateStatus() {
        if (heroTitle == null) return;
        boolean running = SoundMonitorService.isRunning;
        testMode = prefs.getBoolean("test_mode", false);

        heroPill.setText(running ? "\u25CF  Listening\u2026" : "\u25CF  Paused");
        heroPill.setTextColor(running ? SOFT : MUTED);
        heroTitle.setText(running ? "Listening" : "Ready");
        heroSub.setText(running
                ? (testMode ? "Test mode \u2014 actions suppressed" : "Say, snap or clap to control your phone.")
                : "Tap the hand to start listening.");

        String single = actionLabel(prefs.getString("single_action", "down"));
        String dbl = actionLabel(prefs.getString("double_action", "up"));
        fingerSub.setText(single + " / " + dbl);
        singleSummary.setText("Single sound \u2192 " + single);
        doubleSummary.setText("Double sound \u2192 " + dbl);

        boolean soundOn = prefs.getBoolean("sound_enabled", true);
        if (fingerSwitch.isChecked() != soundOn) fingerSwitch.setChecked(soundOn);
        boolean lockOn = prefs.getBoolean("lock_enabled", false);
        if (lockSwitch.isChecked() != lockOn) lockSwitch.setChecked(lockOn);
        if (testSwitch.isChecked() != testMode) testSwitch.setChecked(testMode);

        int delayMs = prefs.getInt("double_delay_ms", 400);
        delayLabel.setText(delayMs + " ms  \u25BE");
        int prog = (delayMs - 200) / 50;
        if (delaySeek.getProgress() != prog) delaySeek.setProgress(prog);

        boolean hasSample = prefs.getString("custom_sample_uri", null) != null;
        if (sampleStatus != null) sampleStatus.setText(hasSample ? "Sample stored" : "No sample imported");

        testStatus.setText(prefs.getString("last_test", "Test results will appear here while listening."));
    }

    private void requestAudio() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        else Toast.makeText(this, "Microphone permission is already granted", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int request, String[] perms, int[] results) {
        super.onRequestPermissionsResult(request, perms, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        Toast.makeText(this, granted ? "Permission granted \u2014 tap the hand to start" : "Permission was not granted",
                Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        if (heroTitle != null) heroTitle.postDelayed(this::updateStatus, 500);
    }

    private void stopListening() {
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_STOP);
        startService(i);
        updateStatus();
    }

    private void importSample() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("audio/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_IMPORT && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
            prefs.edit().putString("custom_sample_uri", uri.toString()).apply();
            Toast.makeText(this, "Sample imported. It is stored for future profile matching; import alone does not train a classifier.", Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }

    private void voiceCommand() {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            Toast.makeText(this, "On-device voice recognition is not available on this device. SnapScroll will not use an online fallback.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        try {
            if (voiceRecognizer != null) voiceRecognizer.destroy();
            voiceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            voiceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { Toast.makeText(MainActivity.this, "Listening for one command\u2026", Toast.LENGTH_SHORT).show(); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) { Toast.makeText(MainActivity.this, "Voice recognition ended (code " + error + ")", Toast.LENGTH_SHORT).show(); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) runVoiceAction(matches.get(0));
                    if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say scroll down, scroll up, or lock screen");
            voiceRecognizer.startListening(intent);
        } catch (Exception e) {
            if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
            Toast.makeText(this, "On-device voice recognition could not start", Toast.LENGTH_LONG).show();
        }
    }

    private void runVoiceAction(String phrase) {
        String spoken = phrase.toLowerCase(Locale.ROOT);
        if (spoken.contains("scroll down")) ScrollAccessibilityService.performScroll(this, false);
        else if (spoken.contains("scroll up")) ScrollAccessibilityService.performScroll(this, true);
        else if (spoken.contains("lock screen") || spoken.contains("lock phone")) {
            if (prefs.getBoolean("lock_enabled", false)) ScrollAccessibilityService.performLock(this);
            else Toast.makeText(this, "Enable the optional voice lock command in Controls first", Toast.LENGTH_LONG).show();
        } else Toast.makeText(this, "Command not recognised: " + phrase, Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
        super.onDestroy();
    }
}
