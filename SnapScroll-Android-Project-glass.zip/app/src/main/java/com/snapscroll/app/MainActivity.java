package com.snapscroll.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity implements SharedPreferences.OnSharedPreferenceChangeListener {
    private static final int REQ_AUDIO = 10, REQ_NOTIF = 11, REQ_IMPORT = 12;
    private static final int BG = 0xFF000000, FG = 0xFFF7F7FA, MUTED = 0xFFA3A3AD;
    private static final int PURPLE = 0xFFA855F7, SOFT = 0xFFC084FC, GREEN = 0xFF72DDA0;
    private static final String[] NAV_LABELS = {"Home", "Controls", "Test", "Settings"};
    private static final String[] NAV_GLYPHS = {"\u2302", "\u2637", "\u2727", "\u2699"};
    private static final String[] ACTION_LABELS = {"Scroll down", "Scroll up", "Do nothing"};
    private static final String[] ACTION_VALUES = {"down", "up", "none"};

    private SpeechRecognizer voiceRecognizer;
    private SharedPreferences prefs;
    private final View[] pages = new View[4];
    private final TextView[] navItems = new TextView[4];
    private TextView statusText, serviceStatus, actionSummary, singleSummary, doubleSummary, testStatus;
    private Switch testSwitch, lockSwitch;
    private boolean testMode = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("snapscroll", MODE_PRIVATE);
        testMode = prefs.getBoolean("test_mode", false);
        buildUi();
        selectTab(0);
    }

    @Override protected void onResume() {
        super.onResume();
        prefs.registerOnSharedPreferenceChangeListener(this);
        updateStatus();
    }

    @Override protected void onPause() {
        prefs.unregisterOnSharedPreferenceChangeListener(this);
        super.onPause();
    }

    @Override public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
        runOnUiThread(this::updateStatus);
    }

    private int dp(float n) { return (int) (n * getResources().getDisplayMetrics().density + .5f); }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setPadding(dp(2), dp(5), dp(2), dp(5));
        return t;
    }

    private TextView screenTitle(String s) {
        TextView t = text(s, 30, FG);
        t.setTypeface(null, 1);
        t.setPadding(dp(2), dp(4), dp(2), dp(12));
        return t;
    }

    private GradientDrawable glass(float radiusDp, int startColor, int strokeColor) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{startColor, 0x0DFFFFFF});
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private LinearLayout card(LinearLayout parent, String title) {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setPadding(dp(18), dp(14), dp(18), dp(16));
        p.setBackground(glass(22, 0x1FFFFFFF, 0x26FFFFFF));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(16);
        parent.addView(p, lp);
        TextView t = text(title, 11, SOFT);
        t.setLetterSpacing(.12f);
        p.addView(t);
        return p;
    }

    private TextView makeButton(String label, GradientDrawable bg, int color, Runnable action) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextSize(15);
        b.setTextColor(color);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(14), dp(14), dp(14), dp(14));
        b.setBackground(bg);
        b.setClickable(true);
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private TextView glassButton(String label, Runnable action) {
        return makeButton(label, glass(16, 0x1AFFFFFF, 0x33FFFFFF), FG, action);
    }

    private TextView primaryButton(String label, Runnable action) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(PURPLE);
        g.setCornerRadius(dp(16));
        return makeButton(label, g, 0xFFFFFFFF, action);
    }

    private void styleSwitch(Switch s, String label) {
        s.setText(label);
        s.setTextColor(FG);
        s.setTextSize(15);
        s.setPadding(0, dp(8), 0, dp(8));
    }

    private LinearLayout column() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(22), dp(28), dp(22), dp(130));
        return c;
    }

    private View page(LinearLayout col) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.addView(col);
        return sv;
    }

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        pages[0] = page(homePage());
        pages[1] = page(controlsPage());
        pages[2] = page(testPage());
        pages[3] = page(settingsPage());
        for (View v : pages) frame.addView(v, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams navParams = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        navParams.setMargins(dp(16), 0, dp(16), dp(18));
        frame.addView(navBar(), navParams);
        setContentView(frame);
        updateStatus();
    }

    private LinearLayout homePage() {
        LinearLayout c = column();
        TextView brand = text("SNAPSCROLL", 13, SOFT);
        brand.setLetterSpacing(.18f);
        c.addView(brand);
        TextView heading = text("Sound in.\nScroll on.", 34, FG);
        heading.setTypeface(null, 1);
        heading.setPadding(0, dp(10), 0, dp(4));
        c.addView(heading);
        c.addView(text("A quiet, on-device sound controller", 14, MUTED));

        LinearLayout listen = card(c, "LISTENING");
        statusText = text("", 20, FG);
        listen.addView(statusText);
        serviceStatus = text("", 13, MUTED);
        listen.addView(serviceStatus);
        listen.addView(primaryButton("Start listening", this::startListening));
        listen.addView(glassButton("Pause listening", this::stopListening));

        LinearLayout act = card(c, "CURRENT ACTIONS");
        actionSummary = text("", 14, MUTED);
        act.addView(actionSummary);
        act.addView(glassButton("Change actions", () -> selectTab(1)));
        return c;
    }

    private LinearLayout controlsPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Controls"));

        LinearLayout actions = card(c, "SOUND ACTIONS");
        singleSummary = text("", 15, FG);
        actions.addView(singleSummary);
        actions.addView(glassButton("Set single sound action", () -> pickAction("single_action", "Single sound")));
        doubleSummary = text("", 15, FG);
        actions.addView(doubleSummary);
        actions.addView(glassButton("Set double sound action", () -> pickAction("double_action", "Double sound")));

        LinearLayout sample = card(c, "CUSTOM SAMPLE");
        sample.addView(text("Stores an audio file you choose. Importing does not train a classifier yet.", 13, MUTED));
        sample.addView(glassButton("Import a custom sound sample", this::importSample));

        LinearLayout voice = card(c, "VOICE & LOCK");
        lockSwitch = new Switch(this);
        styleSwitch(lockSwitch, "Allow voice command to lock screen");
        lockSwitch.setChecked(prefs.getBoolean("lock_enabled", false));
        lockSwitch.setOnCheckedChangeListener((v, checked) -> prefs.edit().putBoolean("lock_enabled", checked).apply());
        voice.addView(lockSwitch);
        voice.addView(text("Screen locking works only through the on-demand voice command. Sound-triggered locking is off.", 13, MUTED));
        voice.addView(glassButton("Voice command (on demand)", this::voiceCommand));
        return c;
    }

    private LinearLayout testPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Test"));

        LinearLayout t = card(c, "TEST SOUND MODE");
        testSwitch = new Switch(this);
        styleSwitch(testSwitch, "Test only \u2014 never scroll or lock");
        testSwitch.setChecked(testMode);
        testSwitch.setOnCheckedChangeListener((v, checked) -> {
            testMode = checked;
            prefs.edit().putBoolean("test_mode", checked).apply();
            updateStatus();
        });
        t.addView(testSwitch);
        t.addView(text("Test mode reports what would happen without scrolling or locking. Start listening first.", 13, MUTED));

        LinearLayout r = card(c, "LAST TEST RESULT");
        testStatus = text("", 14, FG);
        r.addView(testStatus);
        r.addView(glassButton("Clear test result", () -> prefs.edit().remove("last_test").apply()));
        return c;
    }

    private LinearLayout settingsPage() {
        LinearLayout c = column();
        c.addView(screenTitle("Settings"));

        LinearLayout perms = card(c, "PERMISSIONS");
        perms.addView(glassButton("Grant microphone permission", this::requestAudio));
        perms.addView(glassButton("Notification settings", this::openNotificationSettings));
        perms.addView(glassButton("Enable SnapScroll accessibility", () ->
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));

        LinearLayout about = card(c, "PRIVACY");
        about.addView(text("Offline processing \u00b7 No account \u00b7 No cloud \u00b7 No ads", 13, MUTED));
        about.addView(text("SnapScroll uses a transient detector, not a trained snap, pop or clap classifier. Do not rely on it in noisy places or for safety.", 13, MUTED));
        return c;
    }

    private LinearLayout navBar() {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(8), dp(10), dp(8), dp(10));
        nav.setBackground(glass(28, 0x1AFFFFFF, 0x33FFFFFF));
        for (int i = 0; i < 4; i++) {
            final int index = i;
            TextView item = new TextView(this);
            item.setText(NAV_GLYPHS[i] + "\n" + NAV_LABELS[i]);
            item.setTextSize(11);
            item.setGravity(Gravity.CENTER);
            item.setTextColor(MUTED);
            item.setClickable(true);
            item.setOnClickListener(v -> selectTab(index));
            navItems[i] = item;
            nav.addView(item, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        return nav;
    }

    private void selectTab(int index) {
        for (int i = 0; i < pages.length; i++) {
            pages[i].setVisibility(i == index ? View.VISIBLE : View.GONE);
            navItems[i].setTextColor(i == index ? SOFT : MUTED);
        }
    }

    private String actionLabel(String value) {
        if ("down".equals(value)) return "Scroll down";
        if ("up".equals(value)) return "Scroll up";
        return "Do nothing";
    }

    private void pickAction(String key, String title) {
        new AlertDialog.Builder(this).setTitle(title).setItems(ACTION_LABELS, (d, which) -> {
            prefs.edit().putString(key, ACTION_VALUES[which]).apply();
            Toast.makeText(this, title + " set to " + ACTION_LABELS[which], Toast.LENGTH_SHORT).show();
        }).show();
    }

    private void openNotificationSettings() {
        if (Build.VERSION.SDK_INT >= 26) {
            startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, getPackageName()));
        }
    }

    private void updateStatus() {
        if (statusText == null) return;
        boolean running = SoundMonitorService.isRunning;
        testMode = prefs.getBoolean("test_mode", false);
        statusText.setText(running ? "\u25CF  Listening" : "\u25CF  Paused");
        statusText.setTextColor(running ? GREEN : FG);
        serviceStatus.setText(running
                ? (testMode ? "Test mode active \u2014 actions suppressed" : "Listening locally in the background")
                : "Microphone service is not running");

        String single = actionLabel(prefs.getString("single_action", "down"));
        String dbl = actionLabel(prefs.getString("double_action", "up"));
        actionSummary.setText("Single sound \u2192 " + single + "\nDouble sound \u2192 " + dbl);
        singleSummary.setText("Single sound \u2192 " + single);
        doubleSummary.setText("Double sound \u2192 " + dbl);

        testStatus.setText(prefs.getString("last_test", "Test results will appear here while listening."));
        if (testSwitch.isChecked() != testMode) testSwitch.setChecked(testMode);
        boolean lockOn = prefs.getBoolean("lock_enabled", false);
        if (lockSwitch.isChecked() != lockOn) lockSwitch.setChecked(lockOn);
    }

    private void requestAudio() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        else Toast.makeText(this, "Microphone permission is already granted", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int request, String[] perms, int[] results) {
        super.onRequestPermissionsResult(request, perms, results);
        boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
        Toast.makeText(this, granted ? "Permission granted \u2014 tap Start listening" : "Permission was not granted",
                Toast.LENGTH_SHORT).show();
        updateStatus();
    }

    private void startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        if (statusText != null) statusText.postDelayed(this::updateStatus, 500);
    }

    private void stopListening() {
        Intent i = new Intent(this, SoundMonitorService.class);
        i.setAction(SoundMonitorService.ACTION_STOP);
        startService(i);
        updateStatus();
    }

    private void importSample() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("audio/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == REQ_IMPORT && result == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) { }
            prefs.edit().putString("custom_sample_uri", uri.toString()).apply();
            Toast.makeText(this, "Sample imported. It is stored for future profile matching; import alone does not train a classifier.", Toast.LENGTH_LONG).show();
        }
        updateStatus();
    }

    private void voiceCommand() {
        if (Build.VERSION.SDK_INT < 31 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            Toast.makeText(this, "On-device voice recognition is not available on this device. SnapScroll will not use an online fallback.", Toast.LENGTH_LONG).show();
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { requestAudio(); return; }
        try {
            if (voiceRecognizer != null) voiceRecognizer.destroy();
            voiceRecognizer = SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            voiceRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { Toast.makeText(MainActivity.this, "Listening for one command\u2026", Toast.LENGTH_SHORT).show(); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) { Toast.makeText(MainActivity.this, "Voice recognition ended (code " + error + ")", Toast.LENGTH_SHORT).show(); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    if (matches != null && !matches.isEmpty()) runVoiceAction(matches.get(0));
                    if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Say scroll down, scroll up, or lock screen");
            voiceRecognizer.startListening(intent);
        } catch (Exception e) {
            if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
            Toast.makeText(this, "On-device voice recognition could not start", Toast.LENGTH_LONG).show();
        }
    }

    private void runVoiceAction(String phrase) {
        String spoken = phrase.toLowerCase(Locale.ROOT);
        if (spoken.contains("scroll down")) ScrollAccessibilityService.performScroll(this, false);
        else if (spoken.contains("scroll up")) ScrollAccessibilityService.performScroll(this, true);
        else if (spoken.contains("lock screen") || spoken.contains("lock phone")) {
            if (prefs.getBoolean("lock_enabled", false)) ScrollAccessibilityService.performLock(this);
            else Toast.makeText(this, "Enable the optional voice lock command in Controls first", Toast.LENGTH_LONG).show();
        } else Toast.makeText(this, "Command not recognised: " + phrase, Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        if (voiceRecognizer != null) { voiceRecognizer.destroy(); voiceRecognizer = null; }
        super.onDestroy();
    }
}
