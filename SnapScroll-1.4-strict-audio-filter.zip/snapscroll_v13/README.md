# SnapScroll 1.4 — sound-triggered Android controls

SnapScroll has three selectable trigger types: **Your sound**, **Clap**, and **Whistle**. Audio processing is local to the phone. The enrolled custom sound is stored as a compact numeric acoustic fingerprint; raw enrollment or listening audio is not saved by this app.

## Changes in 1.4

- Added **Whistle** as a third independent trigger, using a sustained tonal/narrow-band score and a minimum duration check.
- Tightened the event gate and clap criteria to reduce false activations from quiet tongue/lip clicks and incidental taps. This is deliberately conservative and may miss softer or distant claps.
- Disabled automatic gain control and microphone noise processing in the listener. On some phones AGC raises tiny mouth clicks and causes accidental triggers; unprocessed input is more consistent, though device microphones still vary.
- Expanded the double-sound timing slider to **0–2,000 ms** in 100 ms steps. `0 ms` means single-only mode; any positive value is the maximum interval between two recognized sound events.
- Each trigger has separately configurable actions for **one sound** and **two sounds**. The first event waits for the selected window; if a second recognized event arrives inside it, only the double action runs. If not, the single action runs. A later event starts a new window.
- Added **Lock screen** and **Wake screen** actions. Wake only wakes the display; it does not unlock the device or bypass PIN, password, pattern, or biometrics. Android does not permit an ordinary app to bypass the secure lock screen.
- If one acoustic event matches multiple enabled trigger profiles with similar confidence, it is ignored rather than assigning the same sound to two different commands.
- Added separate test buttons for one-sound and two-sound actions.
- Haptic feedback remains silent (no beep) so the feedback is less likely to be detected again by the microphone.

## How the timing window works

Example with a 1,000 ms window:

1. First recognized sound: start the 1-second timer; do not run the single action yet.
2. Second recognized sound within 1,000 ms: cancel the pending single action and run the configured two-sound action once.
3. No second recognized sound before the timer expires: run the configured one-sound action once.
4. A sound after the timer expires begins a new sequence. It is not paired with the previous sound.

The timing slider spans 0 to 2,000 ms (0 to 2 seconds), not 0 to 2 milliseconds. A 2 ms human-sound pairing window would be too short for two separate claps or whistles.

## Setup

1. Grant Microphone permission and enable SnapScroll under Android Accessibility settings. Accessibility is needed for scrolling and lock-screen actions.
2. Enable any of the three trigger types you want to use.
3. For **Your sound**, record three examples of the same short, repeatable sound.
4. Expand a trigger and configure what one sound does and what two sounds do.
5. Set the double-sound window. Start at 1,000 ms and tune it after real-device testing.
6. Use the one-sound and two-sound test buttons to verify phone actions separately from microphone detection.

## Accuracy and security limitations

This is an on-device signal-processing implementation, not a trained neural-network classifier. The listener uses a conservative amplitude gate and stricter clap duration/spectral criteria, and does not enable AGC or microphone noise processing. This should reduce false activations from small mouth clicks, but cannot guarantee rejection of every wall tap, handling noise, echo, or other impact. A clap and a physically similar impact can produce very similar waveforms at one microphone. Very quiet or distant sounds can only be detected when they remain sufficiently above the room's noise floor. Whistle detection is a heuristic tonal detector and needs tuning on the target phone. Real-device testing is required; do not assume identical sensitivity across phones.

The app can request Android's supported screen-lock global action and can request a screen wake. It cannot unlock a secured phone. The user must still authenticate normally.

## Build an APK

### Android Studio

1. Open this folder as an existing project in Android Studio.
2. Allow Android Studio to install Android SDK Platform 35 and the required Android Gradle Plugin / Gradle components.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions

The included `.github/workflows/android-build.yml` builds a debug APK on push to `main`/`master`, or when manually started with **Actions → Build SnapScroll APK → Run workflow**. It uploads the APK as an artifact named `SnapScroll-debug-apk`.

This workspace does not include Android SDK build tools, so this source ZIP has not been compiled or tested on a physical phone. It is an editable Android source project, not an installable APK.
