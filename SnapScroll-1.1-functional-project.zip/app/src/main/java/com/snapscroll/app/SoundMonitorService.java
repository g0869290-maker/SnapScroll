package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;

public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static volatile boolean isRunning = false;
    public static volatile String lastError = null;
    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private AudioRecord recorder;
    private Thread worker;
    private volatile boolean keepRunning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastEventAt = 0;
    private long pendingSingleAt = 0;
    private static final long DOUBLE_WINDOW_MS = 420;
    private static final long EVENT_GUARD_MS = 180;

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopMonitoring(); stopSelf(); return START_NOT_STICKY; }
        if (!isRunning) startMonitoring();
        if (!isRunning) return START_NOT_STICKY;
        handler.post(this::updateVoice);
        return START_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SnapScroll is active")
                .setContentText("Listening on-device · Tap to open controls").setContentIntent(pi).setOngoing(true).build();
    }
    private void startMonitoring() {
        try {
            lastError = null;
            startForeground(NOTIFICATION_ID, notification());
            final int rate = 16000;
            int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android reports no usable microphone buffer (" + min + ")");
            // MIC is supported more consistently than the optional UNPROCESSED source.
            int bufferBytes = Math.max(min, rate * 2); // 1 second of 16-bit mono PCM
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufferBytes);
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED)
                throw new IllegalStateException("Microphone could not be initialised");
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING)
                throw new IllegalStateException("Android did not start microphone recording");
            keepRunning = true;
            isRunning = true;
            worker = new Thread(this::readLoop, "SnapScroll-Audio");
            worker.start();
        } catch (Exception e) {
            keepRunning = false;
            isRunning = false;
            lastError = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            if (recorder != null) {
                try { recorder.release(); } catch (Exception ignored) { }
                recorder = null;
            }
            stopForeground(true);
            stopSelf();
            android.util.Log.e("SnapScroll", "Unable to start microphone", e);
        }
    }
    private void readLoop() {
        short[] data = new short[320]; // 20 ms at 16 kHz
        double noiseFloor = 170.0;
        AudioRecord activeRecorder = recorder;
        while (keepRunning && activeRecorder != null) {
            int n = activeRecorder.read(data, 0, data.length);
            if (n < 0) {
                final int readError = n;
                handler.post(() -> {
                    if (keepRunning) {
                        lastError = "Microphone read failed (" + readError + ")";
                        isRunning = false;
                        stopSelf();
                    }
                });
                break;
            }
            if (n <= 0) continue;
            double sum = 0; int peak = 0; int crossings = 0; short prev = data[0];
            for (int i = 0; i < n; i++) {
                int v = data[i]; sum += (double)v * v; peak = Math.max(peak, Math.abs(v));
                if ((v >= 0 && prev < 0) || (v < 0 && prev >= 0)) crossings++;
                prev = data[i];
            }
            double rms = Math.sqrt(sum / n);
            if (rms < noiseFloor * 2.4) noiseFloor = noiseFloor * .985 + Math.max(35, rms) * .015;
            double threshold = Math.max(700, noiseFloor * 4.2);
            long now = System.currentTimeMillis();
            // Require both a strong block and a sharp peak to avoid triggering on steady noise.
            if (rms > threshold && peak > 2400 && peak > rms * 1.7 && now - lastEventAt > EVENT_GUARD_MS) {
                lastEventAt = now;
                // Lightweight transient gate only. It does not reliably distinguish a snap, pop or clap.
                final int eventCrossings = crossings;
                handler.post(() -> onSoundEvent(eventCrossings));
            }
        }
    }
    private static final String[] IDS = {"snap", "clap", "voice", "custom"};
    private static final String[] DEF_ACT = {"down", "up", "down", "open"};
    private static final boolean[] DEF_ON = {true, true, false, false};
    private String pendingAct = null, pendingPkg = null;

    private boolean on(SharedPreferences p, int i) { return p.getBoolean(IDS[i] + "_on", DEF_ON[i]); }

    /** Picks which sound row a transient belongs to. Rough heuristic only (see README). */
    private int classify(SharedPreferences p, int crossings) {
        int zcr = p.getInt("custom_zcr", 0);
        if (on(p, 3) && zcr > 0 && Math.abs(crossings - zcr) <= Math.max(12, zcr / 4)) return 3;
        boolean snap = on(p, 0), clap = on(p, 1);
        // A snap is usually brighter/shorter than a clap. This zero-crossing split
        // is a lightweight heuristic, not a trained classifier; it will vary by device.
        if (snap && clap) return crossings > 78 ? 0 : 1;
        if (snap) return 0;
        if (clap) return 1;
        return -1;
    }

    private void onSoundEvent(int crossings) {
        final SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        if (!p.getBoolean("sound_enabled", true)) return;
        int row = classify(p, crossings);
        if (row < 0) return;
        final String act = p.getString(IDS[row] + "_act", DEF_ACT[row]);
        final String pkg = p.getString(IDS[row] + "_pkg", null);
        long now = System.currentTimeMillis();
        long windowMs = p.getInt("double_delay_ms", 400);
        if (pendingSingleAt != 0 && now - pendingSingleAt <= windowMs) {
            // Second sound inside the window: run the reverse action instead of the single one.
            pendingSingleAt = 0;
            ScrollAccessibilityService.perform(this, ScrollAccessibilityService.reverse(pendingAct), pendingPkg);
            vibrate(65);
        } else {
            final long stamp = now;
            pendingSingleAt = now; pendingAct = act; pendingPkg = pkg;
            handler.postDelayed(() -> {
                if (pendingSingleAt == stamp) {
                    pendingSingleAt = 0;
                    ScrollAccessibilityService.perform(this, act, pkg);
                    vibrate(35);
                }
            }, windowMs);
        }
    }
    private void vibrate(long ms) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v != null) {
                if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                else v.vibrate(ms);
            }
        } catch (Exception ignored) {}
    }
    // ---- continuous on-device voice ("next" / "back"); best effort, mic is shared with the snap detector ----
    private android.speech.SpeechRecognizer voice;
    private boolean voiceLoop = false;

    private boolean voiceWanted() {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        return isRunning && p.getBoolean("voice_on", false) && Build.VERSION.SDK_INT >= 31
                && android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
    }

    private void updateVoice() {
        if (voiceWanted()) { if (!voiceLoop) { voiceLoop = true; listenOnce(); } }
        else stopVoice();
    }

    private void stopVoice() {
        voiceLoop = false;
        if (voice != null) { try { voice.destroy(); } catch (Exception ignored) { } voice = null; }
    }

    private void listenOnce() {
        if (!voiceLoop || !voiceWanted()) { stopVoice(); return; }
        try {
            if (voice != null) voice.destroy();
            voice = android.speech.SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            voice.setRecognitionListener(new android.speech.RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle b) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float v) { }
                @Override public void onBufferReceived(byte[] b) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int e) { handler.postDelayed(SoundMonitorService.this::listenOnce, 600); }
                @Override public void onEvent(int t, Bundle b) { }
                @Override public void onPartialResults(Bundle b) { }
                @Override public void onResults(Bundle b) {
                    java.util.ArrayList<String> m = b.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION);
                    if (m != null && !m.isEmpty()) voiceAction(m.get(0));
                    handler.postDelayed(SoundMonitorService.this::listenOnce, 250);
                }
            });
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault());
            voice.startListening(i);
        } catch (Exception e) { handler.postDelayed(this::listenOnce, 2000); }
    }

    private void voiceAction(String phrase) {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        String s = phrase.toLowerCase(java.util.Locale.ROOT);
        String act = p.getString("voice_act", "down");
        String pkg = p.getString("voice_pkg", null);
        if (s.contains("next")) { ScrollAccessibilityService.perform(this, act, pkg); vibrate(35); }
        else if (s.contains("back") || s.contains("previous")) { ScrollAccessibilityService.perform(this, ScrollAccessibilityService.reverse(act), pkg); vibrate(35); }
    }

    private void stopMonitoring() {
        stopVoice();
        keepRunning = false; isRunning = false;
        if (recorder != null) { try { recorder.stop(); } catch (Exception ignored) {} try { recorder.release(); } catch (Exception ignored) {} recorder = null; }
        if (worker != null) { worker.interrupt(); worker = null; }
        stopForeground(true);
    }
    @Override public void onDestroy() { stopMonitoring(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
