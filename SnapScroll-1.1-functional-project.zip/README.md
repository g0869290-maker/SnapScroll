# SnapScroll 1.1 — Android project

SnapScroll is a native Android utility that listens for sharp sounds on-device and uses Android Accessibility gestures to perform configured actions in other apps. It does not use an account, cloud service, analytics SDK, or advertising SDK.

## What was repaired in this revision

- Microphone capture now uses Android's standard `MIC` audio source instead of relying on the optional `UNPROCESSED` source.
- Startup checks that the microphone actually entered the recording state and reports a concrete startup/read error in the app.
- The first-run gate requires only microphone and Accessibility access. Notification permission and battery-optimisation exemption are optional; neither should prevent opening the app.
- Toggle changes use checked-state listeners.
- Each expanded sound row has **Test this action now**. This executes the configured action directly, bypassing sound detection, and reports whether Android accepted/delivered the swipe. This separates an Accessibility/gesture problem from a microphone-detection problem.
- Scroll gestures have a longer swipe path and manual-test feedback for delivered, cancelled, or rejected gestures.
- The orange switches use a warm orange checked thumb and muted dark track.
- Sound trigger thresholds were adjusted to be less restrictive while still requiring a sharp transient.

## Important behaviour and limits

The sound engine is still a lightweight transient detector, not a machine-learned finger-snap/clap classifier. The two enabled rows are separated using a simple zero-crossing heuristic, which varies with microphone hardware, distance, room acoustics, and the sound itself. It can mistake other sharp noises for a snap or clap, and it may confuse the two. This revision improves microphone startup and gesture execution but does not claim studio-grade sound classification.

The **Test this action now** button is the key first test:

1. Open a sound row (tap its title area).
2. Set its action to **Scroll down**.
3. Tap **Test this action now** while a scrollable screen in another app is visible.
4. If Android reports the swipe as delivered but the content does not move, that app/screen may not respond to a generic vertical swipe at the screen centre. If Android reports that the service is not connected or the gesture was rejected, check Accessibility setup.
5. Only after the manual action works should sound detection be tested.

A single sound performs the configured action. A second recognised sound within the configured delay performs the reverse action.

Voice command uses Android's on-device speech recognizer when available. Continuous voice recognition and raw microphone detection compete for microphone access on some devices; using voice and transient detection together may reduce reliability. Android 12+ and an available on-device recognizer are required for this feature.

The scrolling operation is a generic screen swipe, not app-specific semantic navigation. It cannot guarantee that every app (or every screen within an app) will scroll. Android Accessibility permission must remain enabled. Android may restrict microphone foreground-service startup when the app is not visible; start listening from SnapScroll while it is open.

## Build an APK

### Android Studio

1. Open this folder as an existing project in Android Studio.
2. Allow Android Studio to install Android SDK Platform 35 and the Android Gradle Plugin / Gradle components if prompted.
3. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

### GitHub Actions

The included `.github/workflows/android-build.yml` builds the debug APK on a push to `main`/`master`, or when manually started with **Actions → Build SnapScroll APK → Run workflow**. The workflow uploads the APK as an artifact named `SnapScroll-debug-apk`.

This workspace does not include Android SDK build tools, so the APK has not been compiled or device-tested here. The ZIP contains the editable Android source project, not an APK.

## First-run setup

1. Install the built APK and open SnapScroll.
2. Grant **Microphone** permission.
3. Enable **SnapScroll** in Android **Accessibility** settings. This is required for cross-app gestures.
4. Notifications and battery optimisation exemption are optional; they are not required to enter the app.
5. Open a scrollable screen in another app, expand a Snap or Clap row, and press **Test this action now**.
6. Once the manual action works, leave the desired sound row enabled and test its sound trigger.
7. Stop listening from the main screen when finished.
