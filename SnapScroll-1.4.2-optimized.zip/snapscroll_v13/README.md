# SnapScroll 1.4.2 (compact two-trigger tuning update)

This update preserves the compact version 1.4 interface and its existing controls. It has exactly two sound triggers: **Your sound** and **Clap**. Whistle is not included. Audio is processed locally; raw microphone audio is not saved or uploaded.

## Kept controls
- Independent enable switches for Your sound and Clap
- Separate one-sound and two-sound actions for each trigger
- Scroll down, Scroll up, Go back, Open app, Lock screen and Wake screen
- Configurable 0–2,000 ms double-sound window (0 means single-only)
- Three-take enrollment for Your sound
- Accessibility service for cross-app gestures and lock-screen action

## Reliability changes
- Fixed a crash in the master sound-enable update: it previously referenced a nonexistent third trigger.
- Reduced the event debounce from 180 ms to 65 ms so two distinct claps closer together are not discarded.
- Relaxed the adaptive sound onset gate while retaining peak and spectral checks.
- Added a 40 ms pre-roll buffer so the start of a clap or enrolled sound is not clipped by the detector.
- Enrolled Your Sound now keeps the three takes as separate templates and matches against the best take instead of averaging away differences between takes. Existing saved fingerprints remain supported.
- Shortened quiet-tail detection slightly and adjusted the adaptive gate to help quieter, clean sounds register.
- Clap threshold is modestly stricter than the previous tuning to reduce incidental clicks while preserving the more responsive onset gate.
- Widened the event-duration range and modestly relaxed recognition thresholds to reduce missed single sounds.
- Added immediate in-app feedback: sound detected, first sound waiting for second, single recognized, or double recognized with measured gap.

## Double-sound behavior
The first recognized event starts the selected timing window. A second recognized event inside that window cancels the pending single action and runs the double action immediately. If no second event arrives, the single action runs when the window expires. The minimum debounce is 65 ms to avoid treating one impact as multiple events while allowing faster pairs.

## Notifications and microphone privacy indicator
Notification permission remains optional. On Android 13 and newer, denying notification permission can hide the foreground-service notification from the notification shade, but Android may still show the service in its active-app/Task Manager area. Android's green microphone privacy indicator is controlled by the operating system and cannot be hidden by an app while the microphone is active. The app must provide a foreground-service notification while it listens in the background.

## Recognition limitations
This remains a lightweight signal-processing recognizer to preserve the small app size; it is not a trained neural-network classifier. Very similar sounds (for example, a sharp mouth click and a small impact) can still be confused. The wider thresholds reduce missed events but may increase false positives depending on the phone microphone and room.

## Build and test status
The source archive was updated and ZIP integrity checked. It has **not** been compiled or tested on a physical phone in this environment. Test Clap and Your Sound on the target device, with the phone at the intended distance, and check the immediate status feedback before relying on configured actions.
