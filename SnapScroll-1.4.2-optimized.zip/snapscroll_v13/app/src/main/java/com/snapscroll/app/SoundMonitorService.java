package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** On-device clap / enrolled-sound listener. Raw microphone audio is never persisted. */
public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static final String ACTION_SOUND_EVENT = "com.snapscroll.SOUND_EVENT";
    public static final String EXTRA_EVENT_MESSAGE = "event_message";
    public static volatile boolean isRunning = false;
    public static volatile String lastError = null;
    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private static final int RATE = 16000;
    private AudioRecord recorder;
    private Thread worker;
    private volatile boolean keepRunning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastAcceptedEventNs = 0;
    private long pendingSingleNs = 0;
    private String pendingAction, pendingPackage, pendingDoubleAction, pendingDoublePackage;
    private Runnable pendingSingleRunnable;
    // Debounce only duplicate fragments of one impact; allow normal fast double claps.
    private static final long MIN_EVENT_GAP_NS = 65_000_000L;

    @Override public void onCreate() { super.onCreate(); createChannel(); }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) { stopMonitoring(); stopSelf(); return START_NOT_STICKY; }
        if (!isRunning) startMonitoring();
        return isRunning ? START_STICKY : START_NOT_STICKY;
    }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SnapScroll is active")
                .setContentText("Listening for your sound or clap · on-device").setContentIntent(pi).setOngoing(true).build();
    }
    private void startMonitoring() {
        try {
            lastError = null;
            startForeground(NOTIFICATION_ID, notification());
            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android reports no usable microphone buffer: " + min);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE * 2));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Microphone could not be initialised");
            // Keep the microphone signal unprocessed. AGC can amplify tiny tongue/lip clicks
            // until they cross the trigger threshold; device DSP also varies by manufacturer.
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Microphone did not start recording");
            keepRunning = true; isRunning = true;
            worker = new Thread(this::readLoop, "SnapScroll-Audio"); worker.start();
        } catch (Exception e) {
            keepRunning = false; isRunning = false;
            lastError = e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            releaseRecorder(); stopForeground(true); stopSelf();
            android.util.Log.e("SnapScroll", "Unable to start microphone", e);
        }
    }

    private void readLoop() {
        short[] frame = new short[160]; // 10 ms at 16 kHz
        short[] event = new short[160 * 80];
        int eventLength = 0, quietFrames = 0;
        boolean inEvent = false;
        double noiseRms = 28.0;
        // Preserve 40 ms before onset so the clap attack is not clipped by the gate.
        short[] preRoll = new short[160 * 4];
        int preWrite = 0, preCount = 0;
        AudioRecord active = recorder;
        while (keepRunning && active != null) {
            int n = active.read(frame, 0, frame.length);
            if (n < 0) {
                final int err = n;
                handler.post(() -> { lastError = "Microphone read failed (" + err + ")"; isRunning = false; stopSelf(); });
                break;
            }
            if (n <= 0) continue;
            double sum = 0; int peak = 0;
            for (int i = 0; i < n; i++) { int v = frame[i]; sum += (double)v * v; peak = Math.max(peak, Math.abs(v)); }
            double rms = Math.sqrt(sum / n);
            if (!inEvent) {
                noiseRms = noiseRms * 0.985 + Math.min(rms, noiseRms * 2.0) * 0.015;
                // Trigger using the current frame, while preRoll still contains only earlier audio.
                double gate = Math.max(62.0, noiseRms * 2.45);
                if (rms > gate && peak > 320 && peak > rms * 1.28) {
                    inEvent = true; eventLength = 0; quietFrames = 0;
                    int start = (preWrite - preCount + preRoll.length) % preRoll.length;
                    int first = Math.min(preCount, preRoll.length - start);
                    System.arraycopy(preRoll, start, event, 0, first);
                    if (first < preCount) System.arraycopy(preRoll, 0, event, first, preCount - first);
                    eventLength = preCount;
                } else {
                    // Keep a 40 ms rolling history for a clean transient onset.
                    int first = Math.min(n, preRoll.length - preWrite);
                    System.arraycopy(frame, 0, preRoll, preWrite, first);
                    if (first < n) System.arraycopy(frame, first, preRoll, 0, n - first);
                    preWrite = (preWrite + n) % preRoll.length;
                    preCount = Math.min(preRoll.length, preCount + n);
                }
            }
            if (inEvent) {
                int copy = Math.min(n, event.length - eventLength);
                if (copy > 0) { System.arraycopy(frame, 0, event, eventLength, copy); eventLength += copy; }
                if (rms < Math.max(48.0, noiseRms * 1.55)) quietFrames++; else quietFrames = 0;
                if (quietFrames >= 3 || eventLength >= event.length) {
                    inEvent = false;
                    if (eventLength >= 160) {
                        short[] clip = new short[eventLength];
                        System.arraycopy(event, 0, clip, 0, eventLength);
                        int bestStart = 0, bestPeak = 0;
                        for (int start = 0; start + 160 <= clip.length; start += 80) {
                            int localPeak = 0;
                            for (int j = start; j < start + 160; j++) localPeak = Math.max(localPeak, Math.abs(clip[j]));
                            if (localPeak > bestPeak) { bestPeak = localPeak; bestStart = start; }
                        }
                        // Use an 80 ms window around the transient, not just 20 ms. This
                        // gives the fingerprint enough spectral context to be repeatable.
                        short[] peakFrame = new short[1280];
                        int copyFrom = Math.max(0, Math.min(bestStart - 480, Math.max(0, clip.length - peakFrame.length)));
                        int copyCount = Math.min(peakFrame.length, clip.length - copyFrom);
                        System.arraycopy(clip, copyFrom, peakFrame, 0, copyCount);
                        double[] features = AudioFeatures.extract(peakFrame, copyCount);
                        long now = SystemClock.elapsedRealtimeNanos();
                        final int durationFrames = eventLength / 160;
                        if (now - lastAcceptedEventNs >= MIN_EVENT_GAP_NS) {
                            lastAcceptedEventNs = now;
                            handler.post(() -> classifyAndDispatch(features, durationFrames, now));
                        }
                    }
                    eventLength = 0; quietFrames = 0;
                }
            }
        }
    }

    private void classifyAndDispatch(double[] features, int durationFrames, long eventNs) {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        if (!p.getBoolean("sound_enabled", true)) return;
        boolean clapOn = p.getBoolean("clap_on", true);
        boolean customOn = p.getBoolean("custom_on", false) && p.getString("custom_feature", null) != null;
        double clapScore = AudioFeatures.clapScore(features);
        double[] template = AudioFeatures.decode(p.getString("custom_feature", null));
        double customScore = AudioFeatures.maxSimilarity(features, p.getString("custom_features", null), template);

        // Two trigger profiles only. Custom sounds use a slightly tolerant cosine
        // threshold; clap uses event duration plus broadband spectral evidence.
        boolean[] match = new boolean[] {
                customOn && durationFrames >= 2 && durationFrames <= 60 && customScore >= 0.83,
                clapOn && durationFrames >= 2 && durationFrames <= 40 && clapScore >= 0.60
        };
        double[] scores = new double[] { customScore, clapScore };
        int best = -1;
        double bestScore = 0, secondScore = 0;
        for (int i = 0; i < match.length; i++) {
            if (!match[i]) continue;
            if (scores[i] > bestScore) { secondScore = bestScore; bestScore = scores[i]; best = i; }
            else if (scores[i] > secondScore) secondScore = scores[i];
        }
        // If two trigger profiles claim the same event with nearly equal confidence,
        // ignore it rather than firing an unintended action.
        if (best < 0 || (secondScore > 0 && bestScore - secondScore < 0.07)) return;
        String id = new String[] { "custom", "clap" }[best];
        broadcastEvent((best == 0 ? "Your sound" : "Clap") + " detected");
        String defaultAction = new String[] { "down", "up" }[best];
        String action = p.getString(id + "_act", defaultAction);
        String doubleAction = p.getString(id + "_double_act", new String[] { "up", "down" }[best]);
        String pkg = p.getString(id + "_pkg", null);
        dispatchTimed(action, pkg, doubleAction, pkg, eventNs, p.getInt("double_delay_ms", 1000));
    }

    private void dispatchTimed(String action, String pkg, String doubleAction, String doublePkg, long nowNs, int windowMs) {
        long windowNs = Math.max(0, Math.min(2000, windowMs)) * 1_000_000L;
        if (windowNs == 0) {
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null; pendingSingleNs = 0;
            broadcastEvent("Single sound recognized");
            ScrollAccessibilityService.perform(this, action, pkg);
            buzz(false);
            return;
        }
        if (pendingSingleNs != 0) {
            long gapMs = (nowNs - pendingSingleNs) / 1_000_000L;
            if (gapMs <= windowNs / 1_000_000L) {
                pendingSingleNs = 0;
                if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
                pendingSingleRunnable = null;
                getSharedPreferences("snapscroll", MODE_PRIVATE).edit().putInt("last_gap_ms", (int) gapMs).apply();
                broadcastEvent("Double sound recognized · " + gapMs + " ms apart");
                ScrollAccessibilityService.perform(this, pendingDoubleAction, pendingDoublePackage);
                pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null;
                buzz(true);
                return;
            }
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            broadcastEvent("Single sound recognized");
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
            pendingSingleNs = 0; pendingAction = null; pendingPackage = null;
        }
        broadcastEvent("First sound detected · waiting for second");
        pendingSingleNs = nowNs; pendingAction = action; pendingPackage = pkg;
        pendingDoubleAction = doubleAction; pendingDoublePackage = doublePkg;
        final long token = nowNs;
        Runnable single = () -> {
            if (pendingSingleNs == token) {
                pendingSingleNs = 0;
                broadcastEvent("Single sound recognized");
                ScrollAccessibilityService.perform(this, action, pkg);
                pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null; pendingSingleRunnable = null;
            }
        };
        pendingSingleRunnable = single;
        handler.postDelayed(single, windowMs);
        buzz(false);
    }

    private void broadcastEvent(String message) {
        Intent event = new Intent(ACTION_SOUND_EVENT);
        event.setPackage(getPackageName());
        event.putExtra(EXTRA_EVENT_MESSAGE, message);
        sendBroadcast(event);
    }

    private void buzz(boolean doubled) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            long[] pattern = doubled ? new long[]{0, 55, 65, 55} : new long[]{0, 28};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        } catch (Exception ignored) { }
    }

    private void releaseRecorder() {
        if (recorder != null) { try { recorder.stop(); } catch (Exception ignored) { } try { recorder.release(); } catch (Exception ignored) { } recorder = null; }
    }
    private void stopMonitoring() {
        keepRunning = false; isRunning = false;
        if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
        pendingSingleRunnable = null;
        if (pendingSingleNs != 0 && pendingAction != null) ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
        pendingSingleNs = 0; pendingAction = null; pendingPackage = null; pendingDoubleAction = null; pendingDoublePackage = null;
        releaseRecorder();
        if (worker != null) { worker.interrupt(); worker = null; }
        stopForeground(true);
    }
    @Override public void onDestroy() { stopMonitoring(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
