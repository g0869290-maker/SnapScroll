plugins { id("com.android.application") }

android {
    namespace = "com.snapscroll.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.snapscroll.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 8
        versionName = "1.4.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
