# SnapScroll 1.0 — Android project

SnapScroll is a small native Android utility prototype. It is designed for offline, on-device operation and has no account, cloud service, analytics SDK, or advertising SDK.

## Build

1. Install Android Studio on a computer.
2. Open this `SnapScroll` folder as an existing project.
3. Allow Android Studio to install the Android SDK Platform 35 and the Android Gradle Plugin / Gradle components if prompted.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

This workspace did not contain the Android SDK, Android build tools, or a working network route to download them. Therefore no APK has been compiled here. The source project is supplied instead of an unverified or fabricated APK.

## Current implementation

- Native Java Android app, minimum Android 8.0 (API 26), target API 35.
- Dark minimal dashboard.
- Runtime microphone permission request and foreground microphone service with persistent notification.
- On-device PCM transient detector with a noise-adaptive threshold.
- Single / double event timing (420 ms window), vibration feedback, and configurable scroll direction preferences.
- Test Mode suppresses actions and reports that no action was executed.
- Accessibility gesture fallback for vertical scrolling.
- Optional on-demand voice command using Android on-device speech recognition only (Android 12+ when the device provides an offline recognition service); no online voice fallback.
- Audio document picker for importing a custom sample URI.

## Important limitations — not production-certified

The current audio engine is a **transient detector, not a trained snap/pop/clap classifier**. It cannot reliably distinguish finger snaps, finger pops, claps, speech bursts, keyboard clicks, or other sharp sounds. Its rough brightness label is diagnostic only. Do not rely on it in noisy environments or for safety-critical actions. Sound-triggered screen locking is intentionally not connected; screen lock is available only through the optional on-demand voice command.

Importing a custom sound currently stores its document URI; it does not train a model. The built-in sound profiles, calibrated custom profiles, per-app semantic navigation (e.g. next Reel/Short), reboot auto-start, and fully configurable voice phrase editor are not yet implemented. Voice commands require Android 12+ with an available on-device speech recognizer. The scrolling fallback is a generic swipe and may behave differently across apps. Android may restrict background microphone startup, especially after reboot; SnapScroll does not bypass those platform restrictions.

## First-run setup on device

1. Install the debug APK and open SnapScroll.
2. Grant microphone permission.
3. Grant notification permission for the persistent listening notification.
4. Open Android Accessibility settings and enable SnapScroll only if you want it to perform scroll gestures / screen lock.
5. Start listening from the app. Use Test Sound Mode first; it must not scroll or lock.
6. Stop listening when finished.

The microphone service must be started while the app is visible and permission is granted. Do not expect it to auto-start after reboot in this prototype.
