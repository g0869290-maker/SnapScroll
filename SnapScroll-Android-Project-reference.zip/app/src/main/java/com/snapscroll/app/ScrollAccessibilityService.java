package com.snapscroll.app;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.os.Build;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class ScrollAccessibilityService extends AccessibilityService {
    private static volatile ScrollAccessibilityService instance;
    @Override protected void onServiceConnected() { super.onServiceConnected(); instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }

    public static void performScroll(Context context, boolean up) {
        ScrollAccessibilityService s = instance;
        if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT < 24) return;
        float x = s.getResources().getDisplayMetrics().widthPixels * .5f;
        float startY = s.getResources().getDisplayMetrics().heightPixels * (up ? .35f : .72f);
        float endY = s.getResources().getDisplayMetrics().heightPixels * (up ? .72f : .35f);
        Path path = new Path(); path.moveTo(x, startY); path.lineTo(x, endY);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 260);
        s.dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }
    public static void performLock(Context context) {
        ScrollAccessibilityService s = instance;
        if (s == null) { Toast.makeText(context, "Enable SnapScroll in Accessibility settings first", Toast.LENGTH_SHORT).show(); return; }
        if (Build.VERSION.SDK_INT >= 28) s.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN);
    }
}
