# SnapScroll 1.5

SnapScroll is an Android accessibility-based sound controller. It can trigger configured scroll, back, open-app, lock-screen, or wake-screen actions from a sound event. Raw microphone audio is processed locally and is not uploaded or saved as recordings.

## Sound recognition in 1.5

- **Clap and Whistle:** now use Google's MediaPipe Tasks Audio with the YAMNet on-device audio classifier. YAMNet predicts 521 AudioSet sound classes, including separate `Clapping`, `Finger snapping`, and `Whistling` classes. SnapScroll checks the clap prediction against finger-snapping, tap, knock, and slam scores before accepting a clap.
- **Event capture:** the old 20 ms peak-only classification and contradictory minimum-duration rule have been removed. A lightweight waveform gate captures a candidate event with surrounding audio; the classifier decides what it is. The classifier input is a 0.975-second mono 16 kHz clip.
- **Your sound:** still uses a locally stored acoustic fingerprint rather than a trained personalized neural model. Enrollment now samples a 100 ms segment instead of a 20 ms sliver. The previous profile is cleared once on first launch of 1.5, so record the three samples again.
- **Single/double timing:** the gap is calculated from candidate event timestamps. Single and double actions remain independent for each trigger type.

## Important limitations

YAMNet is a general sound-event model trained on AudioSet, not a model trained specifically on this phone, room, or user's clap. It can still confuse acoustically similar sounds, and low-volume/distant claps may be missed. The thresholds in this version are starting values and need tests on the target phone with actual claps, mouth clicks, finger snaps, wall taps, and background audio. No honest claim of perfect precision can be made without those tests.

`Your sound` is still a small spectral fingerprint matcher, not a learned embedding model. It works best with a distinct, repeatable sound that differs from everyday room sounds. A future truly personalized model should be trained on positive examples of the chosen sound plus negative examples such as tongue clicks, teeth clicks, taps, and speech.

The YAMNet model is downloaded at build time from the MediaPipe community model repository and verified against a pinned SHA-256 checksum. It is packaged in the APK and runs offline after installation. The first build therefore needs network access.

## Build

Open this folder in Android Studio and build the `app` debug APK, or push it to GitHub and run the included `Build SnapScroll APK` workflow. The Gradle pre-build task downloads and checksum-verifies `yamnet.tflite` before packaging. The project uses MediaPipe Tasks Audio `1.2.3`.

## Permissions and Android behavior

- Microphone permission and a foreground microphone service are required for listening.
- Accessibility permission is required for cross-app scrolling and Android global actions.
- Lock screen uses Android's supported Accessibility global action on compatible Android versions.
- Wake screen does not unlock a secured device or bypass its PIN, pattern, password, or biometrics.

## Build/test status

The source ZIP and Gradle configuration have been checked. This environment does not have Android SDK/Gradle installed and cannot compile or run an APK on a physical phone. Device-specific threshold calibration and end-to-end tests are still required.

Build-script fix in 1.5.1: the Kotlin DSL now imports `java.io.File` explicitly and uses `File(...)` for the temporary model download file. This fixes the `Unresolved reference: io` script error reported with Gradle.
