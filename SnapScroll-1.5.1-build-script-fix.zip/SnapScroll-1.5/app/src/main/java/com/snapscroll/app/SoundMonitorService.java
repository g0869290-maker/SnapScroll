package com.snapscroll.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Log;

import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier;
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifier.AudioClassifierOptions;
import com.google.mediapipe.tasks.audio.audioclassifier.AudioClassifierResult;
import com.google.mediapipe.tasks.audio.core.RunningMode;
import com.google.mediapipe.tasks.components.containers.AudioData;
import com.google.mediapipe.tasks.components.containers.AudioData.AudioDataFormat;
import com.google.mediapipe.tasks.components.containers.Category;
import com.google.mediapipe.tasks.components.containers.Classifications;
import com.google.mediapipe.tasks.components.containers.ClassificationResult;
import com.google.mediapipe.tasks.core.BaseOptions;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** On-device sound listener. Raw microphone audio is only held in short-lived memory buffers. */
public class SoundMonitorService extends Service {
    public static final String ACTION_START = "com.snapscroll.START";
    public static final String ACTION_STOP = "com.snapscroll.STOP";
    public static volatile boolean isRunning = false;
    public static volatile String lastError = null;

    private static final String CHANNEL = "snapscroll_listener";
    private static final int NOTIFICATION_ID = 41;
    private static final int RATE = 16000;
    private static final int FRAME_SAMPLES = 160;              // 10 ms
    private static final int CLIP_SAMPLES = 15600;             // YAMNet: 0.975 s at 16 kHz
    private static final int PREROLL_SAMPLES = 11200;           // 700 ms before event end
    private static final int POSTROLL_SAMPLES = 4400;          // 275 ms after event end
    private static final long MIN_EVENT_GAP_NS = 120_000_000L;

    private AudioRecord recorder;
    private AudioClassifier classifier;
    private ExecutorService classifierExecutor;
    private Thread worker;
    private volatile boolean keepRunning;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastCandidateNs = 0;
    private long pendingSingleNs = 0;
    private String pendingAction, pendingPackage, pendingDoubleAction, pendingDoublePackage;
    private Runnable pendingSingleRunnable;

    private static final class PendingClip {
        final float[] samples = new float[CLIP_SAMPLES];
        final long eventNs;
        final int peak;
        int writeIndex = PREROLL_SAMPLES;

        PendingClip(short[] preRoll, int nextPreRollIndex, long eventNs, int peak) {
            this.eventNs = eventNs;
            this.peak = peak;
            int source = nextPreRollIndex;
            for (int i = 0; i < PREROLL_SAMPLES; i++) {
                samples[i] = preRoll[source] / 32768.0f;
                source = (source + 1) % preRoll.length;
            }
        }

        boolean append(short[] frame, int count) {
            int copy = Math.min(count, CLIP_SAMPLES - writeIndex);
            for (int i = 0; i < copy; i++) samples[writeIndex + i] = frame[i] / 32768.0f;
            writeIndex += copy;
            return writeIndex >= CLIP_SAMPLES;
        }
    }

    @Override public void onCreate() { super.onCreate(); createChannel(); }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopMonitoring();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!isRunning) startMonitoring();
        return isRunning ? START_STICKY : START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "SnapScroll listening", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Visible notification while SnapScroll uses the microphone");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private Notification notification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("SnapScroll is active")
                .setContentText("On-device sound recognition: clap, whistle and your sound")
                .setContentIntent(pi).setOngoing(true).build();
    }

    private void startMonitoring() {
        try {
            lastError = null;
            startForeground(NOTIFICATION_ID, notification());

            BaseOptions baseOptions = BaseOptions.builder().setModelAssetPath("yamnet.tflite").build();
            AudioClassifierOptions options = AudioClassifierOptions.builder()
                    .setBaseOptions(baseOptions)
                    .setRunningMode(RunningMode.AUDIO_CLIPS)
                    .setMaxResults(521)
                    .build();
            classifier = AudioClassifier.createFromOptions(this, options);
            classifierExecutor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "SnapScroll-YAMNet");
                t.setPriority(Thread.NORM_PRIORITY - 1);
                return t;
            });

            int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (min <= 0) throw new IllegalStateException("Android reports no usable microphone buffer: " + min);
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(min, RATE * 2));
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("Microphone could not be initialised");
            recorder.startRecording();
            if (recorder.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING) throw new IllegalStateException("Microphone did not start recording");

            keepRunning = true;
            isRunning = true;
            worker = new Thread(this::readLoop, "SnapScroll-Audio");
            worker.start();
        } catch (Exception e) {
            keepRunning = false;
            isRunning = false;
            lastError = "Sound recognition could not start: " + e.getClass().getSimpleName() + ": " + String.valueOf(e.getMessage());
            releaseRecorder();
            releaseClassifier();
            stopForeground(true);
            stopSelf();
            Log.e("SnapScroll", "Unable to start sound recognition", e);
        }
    }

    /**
     * The waveform gate only finds candidate events. YAMNet decides whether a candidate is
     * actually clapping/whistling. No minimum event-duration rule is used: a real short clap
     * must not be rejected just because its tail is shorter than the old threshold.
     */
    private void readLoop() {
        short[] frame = new short[FRAME_SAMPLES];
        short[] preRoll = new short[PREROLL_SAMPLES];
        int preIndex = 0;
        ArrayList<PendingClip> pending = new ArrayList<>();
        boolean inEvent = false;
        int quietFrames = 0;
        int eventSamples = 0;
        int eventPeak = 0;
        long eventStartNs = 0;
        double noiseRms = 24.0;
        AudioRecord active = recorder;

        while (keepRunning && active != null) {
            int n = active.read(frame, 0, frame.length);
            if (n < 0) {
                final int err = n;
                handler.post(() -> {
                    lastError = "Microphone read failed (" + err + ")";
                    isRunning = false;
                    stopSelf();
                });
                break;
            }
            if (n <= 0) continue;

            // Finish all already-open clips with this frame.
            Iterator<PendingClip> iterator = pending.iterator();
            while (iterator.hasNext()) {
                PendingClip clip = iterator.next();
                if (clip.append(frame, n)) {
                    iterator.remove();
                    submitClassification(clip);
                }
            }

            double sum = 0.0;
            int peak = 0;
            for (int i = 0; i < n; i++) {
                int v = frame[i];
                sum += (double)v * v;
                peak = Math.max(peak, Math.abs(v));
            }
            double rms = Math.sqrt(sum / n);

            // Maintain pre-roll in chronological circular-buffer form.
            for (int i = 0; i < n; i++) {
                preRoll[preIndex] = frame[i];
                preIndex = (preIndex + 1) % preRoll.length;
            }

            if (!inEvent) {
                noiseRms = noiseRms * 0.98 + Math.min(rms, noiseRms * 1.6) * 0.02;
                double onsetGate = Math.max(34.0, noiseRms * 2.2);
                // Deliberately capture candidates at a moderate gate; the ML model rejects clicks/taps.
                if (rms > onsetGate && peak > 220 && peak > rms * 1.30) {
                    long now = SystemClock.elapsedRealtimeNanos();
                    if (now - lastCandidateNs >= MIN_EVENT_GAP_NS) {
                        inEvent = true;
                        eventSamples = n;
                        eventPeak = peak;
                        eventStartNs = now;
                        quietFrames = 0;
                    }
                }
            } else {
                eventSamples += n;
                eventPeak = Math.max(eventPeak, peak);
                if (rms < Math.max(32.0, noiseRms * 1.55)) quietFrames++; else quietFrames = 0;
                if (quietFrames >= 4 || eventSamples >= RATE / 2) {
                    inEvent = false;
                    quietFrames = 0;
                    lastCandidateNs = eventStartNs;
                    PendingClip clip = new PendingClip(preRoll, preIndex, eventStartNs, eventPeak);
                    pending.add(clip);
                }
            }
        }
    }

    private void submitClassification(PendingClip clip) {
        ExecutorService executor = classifierExecutor;
        if (executor == null || classifier == null) return;
        try {
            executor.execute(() -> {
                try {
                    float[] scores = classifyWithYamnet(clip.samples);
                    // Use a 100 ms local window from the end of the event for the enrolled profile.
                    short[] local = new short[1600];
                    int offset = PREROLL_SAMPLES - local.length;
                    for (int i = 0; i < local.length; i++) {
                        float v = clip.samples[offset + i];
                        local[i] = (short)Math.max(Short.MIN_VALUE, Math.min(Short.MAX_VALUE, Math.round(v * 32767.0f)));
                    }
                    double[] customFeatures = AudioFeatures.extract(local, local.length);
                    handler.post(() -> classifyAndDispatch(customFeatures, scores, clip.eventNs, clip.peak));
                } catch (Exception e) {
                    Log.e("SnapScroll", "YAMNet classification failed", e);
                    handler.post(() -> lastError = "Sound model error: " + String.valueOf(e.getMessage()));
                }
            });
        } catch (Exception e) {
            Log.e("SnapScroll", "Could not queue sound classification", e);
        }
    }

    private float[] classifyWithYamnet(float[] samples) {
        AudioDataFormat format = AudioDataFormat.builder()
                .setNumOfChannels(1)
                .setSampleRate((float) RATE)
                .build();
        AudioData audioData = AudioData.create(format, samples.length);
        audioData.load(samples);
        AudioClassifierResult result = classifier.classify(audioData);
        float[] scores = new float[521];
        if (result == null) return scores;
        for (ClassificationResult window : result.classificationResults()) {
            for (Classifications head : window.classifications()) {
                for (Category category : head.categories()) {
                    int index = category.index();
                    if (index >= 0 && index < scores.length) {
                        scores[index] = Math.max(scores[index], category.score());
                    }
                }
            }
        }
        return scores;
    }

    private void classifyAndDispatch(double[] customFeatures, float[] scores, long eventNs, int peak) {
        SharedPreferences p = getSharedPreferences("snapscroll", MODE_PRIVATE);
        if (!p.getBoolean("sound_enabled", true)) return;

        boolean clapOn = p.getBoolean("clap_on", true);
        boolean customOn = p.getBoolean("custom_on", false) && p.getString("custom_feature", null) != null;
        boolean whistleOn = p.getBoolean("whistle_on", false);

        double[] template = AudioFeatures.decode(p.getString("custom_feature", null));
        double customScore = AudioFeatures.similarity(customFeatures, template);

        // YAMNet AudioSet class indices: 35 Whistling, 57 Finger snapping, 58 Clapping,
        // 62 Applause, 352 Slam, 353 Knock, and 354 Tap.
        float whistleScore = scoreAt(scores, 35);
        float fingerSnapScore = scoreAt(scores, 57);
        float clapScore = scoreAt(scores, 58);
        float slamScore = scoreAt(scores, 352);
        float knockScore = scoreAt(scores, 353);
        float tapScore = scoreAt(scores, 354);
        float trainWhistleScore = scoreAt(scores, 324);

        // Clapping must win against the most common look-alikes, not merely cross a loudness gate.
        boolean clapMatch = clapOn && peak >= 220 && clapScore >= 0.12f
                && clapScore >= fingerSnapScore * 1.25f
                && clapScore >= tapScore * 1.20f
                && clapScore >= knockScore * 1.20f
                && clapScore >= slamScore * 1.20f;
        boolean whistleMatch = whistleOn && whistleScore >= 0.22f
                && whistleScore >= trainWhistleScore * 1.20f;
        // Enrolled sound uses a longer template sample than v1.4; users are asked to re-record it.
        boolean customMatch = customOn && customScore >= 0.92;

        int matches = (customMatch ? 1 : 0) + (clapMatch ? 1 : 0) + (whistleMatch ? 1 : 0);
        if (matches != 1) {
            Log.d("SnapScroll", String.format(java.util.Locale.US,
                    "YAMNet scores clap=%.3f fingerSnap=%.3f tap=%.3f whistle=%.3f custom=%.3f matches=%d",
                    clapScore, fingerSnapScore, tapScore, whistleScore, customScore, matches));
            return;
        }

        String id = customMatch ? "custom" : clapMatch ? "clap" : "whistle";
        String defaultAction = customMatch ? "down" : clapMatch ? "up" : "back";
        String doubleDefault = customMatch ? "up" : clapMatch ? "down" : "open";
        String action = p.getString(id + "_act", defaultAction);
        String doubleAction = p.getString(id + "_double_act", doubleDefault);
        String pkg = p.getString(id + "_pkg", null);
        dispatchTimed(action, pkg, doubleAction, pkg, eventNs, p.getInt("double_delay_ms", 1000));
    }

    private static float scoreAt(float[] scores, int index) {
        return scores != null && index >= 0 && index < scores.length ? scores[index] : 0f;
    }

    private void dispatchTimed(String action, String pkg, String doubleAction, String doublePkg, long nowNs, int windowMs) {
        long windowNs = Math.max(0, Math.min(2000, windowMs)) * 1_000_000L;
        if (windowNs == 0) {
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            pendingSingleNs = 0;
            ScrollAccessibilityService.perform(this, action, pkg);
            buzz(false);
            return;
        }
        if (pendingSingleNs != 0) {
            long gapMs = (nowNs - pendingSingleNs) / 1_000_000L;
            if (gapMs >= 0 && gapMs <= windowNs / 1_000_000L) {
                pendingSingleNs = 0;
                if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
                pendingSingleRunnable = null;
                getSharedPreferences("snapscroll", MODE_PRIVATE).edit().putInt("last_gap_ms", (int) gapMs).apply();
                ScrollAccessibilityService.perform(this, pendingDoubleAction, pendingDoublePackage);
                pendingAction = null;
                pendingPackage = null;
                pendingDoubleAction = null;
                pendingDoublePackage = null;
                buzz(true);
                return;
            }
            if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
            pendingSingleRunnable = null;
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
            pendingSingleNs = 0;
            pendingAction = null;
            pendingPackage = null;
        }
        pendingSingleNs = nowNs;
        pendingAction = action;
        pendingPackage = pkg;
        pendingDoubleAction = doubleAction;
        pendingDoublePackage = doublePkg;
        final long token = nowNs;
        Runnable single = () -> {
            if (pendingSingleNs == token) {
                pendingSingleNs = 0;
                ScrollAccessibilityService.perform(this, action, pkg);
                pendingAction = null;
                pendingPackage = null;
                pendingDoubleAction = null;
                pendingDoublePackage = null;
                pendingSingleRunnable = null;
            }
        };
        pendingSingleRunnable = single;
        // The short post-roll adds recognition latency. Each clap candidate has the same
        // capture/classification path, so event timestamps still determine single vs. double.
        handler.postDelayed(single, windowMs);
        buzz(false);
    }

    private void buzz(boolean doubled) {
        try {
            Vibrator v = (Vibrator)getSystemService(VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return;
            long[] pattern = doubled ? new long[]{0, 55, 65, 55} : new long[]{0, 28};
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
            else v.vibrate(pattern, -1);
        } catch (Exception ignored) { }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try { recorder.stop(); } catch (Exception ignored) { }
            try { recorder.release(); } catch (Exception ignored) { }
            recorder = null;
        }
    }

    private void releaseClassifier() {
        if (classifierExecutor != null) {
            classifierExecutor.shutdownNow();
            classifierExecutor = null;
        }
        if (classifier != null) {
            try { classifier.close(); } catch (Exception ignored) { }
            classifier = null;
        }
    }

    private void stopMonitoring() {
        keepRunning = false;
        isRunning = false;
        if (pendingSingleRunnable != null) handler.removeCallbacks(pendingSingleRunnable);
        pendingSingleRunnable = null;
        if (pendingSingleNs != 0 && pendingAction != null) {
            ScrollAccessibilityService.perform(this, pendingAction, pendingPackage);
        }
        pendingSingleNs = 0;
        pendingAction = null;
        pendingPackage = null;
        pendingDoubleAction = null;
        pendingDoublePackage = null;
        releaseRecorder();
        releaseClassifier();
        if (worker != null) {
            worker.interrupt();
            worker = null;
        }
        stopForeground(true);
    }

    @Override public void onDestroy() {
        stopMonitoring();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
