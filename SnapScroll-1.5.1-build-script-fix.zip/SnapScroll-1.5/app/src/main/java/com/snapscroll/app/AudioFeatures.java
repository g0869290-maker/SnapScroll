package com.snapscroll.app;

/** Small on-device acoustic fingerprint helper. No audio is stored or uploaded. */
final class AudioFeatures {
    private static final double[] FREQS = {250, 450, 700, 1000, 1400, 1900, 2600, 3600};
    private static final int RATE = 16000;
    private AudioFeatures() {}

    static double[] extract(short[] samples, int length) {
        int n = Math.min(length, samples.length);
        double[] out = new double[9];
        if (n < 40) return out;
        int crossings = 0;
        short prev = samples[0];
        double peak = 0, sumSq = 0;
        for (int i = 0; i < n; i++) {
            double v = samples[i];
            peak = Math.max(peak, Math.abs(v));
            sumSq += v * v;
            if ((samples[i] >= 0 && prev < 0) || (samples[i] < 0 && prev >= 0)) crossings++;
            prev = samples[i];
        }
        double rms = Math.sqrt(sumSq / n);
        if (rms < 1) return out;
        double total = 0;
        for (int b = 0; b < FREQS.length; b++) {
            double omega = 2.0 * Math.PI * FREQS[b] / RATE;
            double coeff = 2.0 * Math.cos(omega), s1 = 0, s2 = 0;
            for (int i = 0; i < n; i++) {
                double window = 0.54 - 0.46 * Math.cos(2.0 * Math.PI * i / Math.max(1, n - 1));
                double x = samples[i] * window;
                double s0 = x + coeff * s1 - s2;
                s2 = s1; s1 = s0;
            }
            double power = Math.max(0, s1 * s1 + s2 * s2 - coeff * s1 * s2);
            out[b] = Math.sqrt(power);
            total += out[b];
        }
        if (total > 0) for (int i = 0; i < 8; i++) out[i] /= total;
        out[8] = (double) crossings / n;
        return out;
    }

    static String encode(double[] f) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < f.length; i++) {
            if (i > 0) b.append(',');
            b.append(String.format(java.util.Locale.US, "%.6f", f[i]));
        }
        return b.toString();
    }

    static double[] decode(String s) {
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length != 9) return null;
            double[] f = new double[9];
            for (int i = 0; i < 9; i++) f[i] = Double.parseDouble(p[i]);
            return f;
        } catch (Exception e) { return null; }
    }

    static double similarity(double[] a, double[] b) {
        if (a == null || b == null) return 0;
        double dot = 0, aa = 0, bb = 0;
        for (int i = 0; i < 9; i++) { dot += a[i] * b[i]; aa += a[i] * a[i]; bb += b[i] * b[i]; }
        return aa <= 0 || bb <= 0 ? 0 : dot / Math.sqrt(aa * bb);
    }


    /** High score for a sustained, tonal whistle; low for broadband impacts and speech. */
    static double whistleScore(double[] f) {
        if (f == null || f.length < 9) return 0;
        double entropy = 0, maxBand = 0, centroid = 0;
        for (int i = 0; i < 8; i++) {
            double v = f[i];
            if (v > 0.0001) entropy -= v * Math.log(v);
            maxBand = Math.max(maxBand, v);
            centroid += v * FREQS[i];
        }
        entropy /= Math.log(8.0);
        double tonal = Math.max(0, Math.min(1, (maxBand - 0.22) / 0.55));
        double lowEntropy = Math.max(0, Math.min(1, (0.78 - entropy) / 0.55));
        double highEnough = centroid < 1100 ? 0 : Math.min(1, (centroid - 1100) / 1800.0);
        return 0.55 * tonal + 0.30 * lowEntropy + 0.15 * highEnough;
    }

    static double clapScore(double[] f) {
        if (f == null) return 0;
        double entropy = 0, centroid = 0;
        for (int i = 0; i < 8; i++) {
            double p = f[i];
            if (p > 0.0001) entropy -= p * Math.log(p);
            centroid += p * FREQS[i];
        }
        entropy /= Math.log(8.0);
        double centroidScore = 1.0 - Math.min(1.0, Math.abs(centroid - 2100.0) / 2600.0);
        double zcrScore = 1.0 - Math.min(1.0, Math.abs(f[8] - 0.22) / 0.30);
        return Math.max(0, Math.min(1, 0.58 * entropy + 0.27 * centroidScore + 0.15 * zcrScore));
    }
}
